import{d4 as l,dy as s,e9 as c,ea as a}from"./PrivyLoginIsland-CDPVUWBM.js";import{n as t}from"./LoadingSkeleton-CeUcJdAQ-CDhyoiGZ.js";const p=({children:o,color:i,isLoading:r,isPulsing:e,...n})=>l.jsx(d,{$color:i,$isLoading:r,$isPulsing:e,...n,children:o});let d=s.span`
  padding: 0.25rem;
  font-size: 0.75rem;
  font-weight: 500;
  line-height: 1rem; /* 150% */
  border-radius: var(--privy-border-radius-xs);
  display: flex;
  align-items: center;
  ${o=>{let i,r;o.$color==="green"&&(i="var(--privy-color-success-dark)",r="var(--privy-color-success-light)"),o.$color==="red"&&(i="var(--privy-color-error)",r="var(--privy-color-error-light)"),o.$color==="gray"&&(i="var(--privy-color-foreground-2)",r="var(--privy-color-background-2)");let e=c`
      from, to {
        background-color: ${r};
      }

      50% {
        background-color: rgba(${r}, 0.8);
      }
    `;return a`
      color: ${i};
      background-color: ${r};
      ${o.$isPulsing&&a`
        animation: ${e} 3s linear infinite;
      `};
    `}}

  ${t}
`;export{p as n};
