import{gO as te,d7 as v,gP as oe,d5 as se,d4 as r,gQ as O,dz as ne,dy as h,gR as ae,gS as ie,dh as le}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as m}from"./index-6mJiZeaw.js";import{i as T,d as X,t as Y,l as H,y as K,c as L,n as de,a as G,s as ce,Q as J,m as ue,g as N,p as S,f as j,v as $,u as D,h as U,b as A}from"./styles-C1EIWAzo-BjovJMX1.js";import{n as k}from"./ScreenLayout-BMEsmxmC-DRwMW8Lv.js";import{n as Z}from"./styles-DVyDvTdj-Be2jo9tP.js";import{m as pe}from"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import{C as me}from"./QrCode-CQ-0kWFq-CW2WL8os.js";import{u as fe,a as he,s as ge,b as ye,c as be,d as _e,e as xe,f as Ee,g as Ce,F as ve}from"./floating-ui.react-DqPcsG6h.js";import{p as ke}from"./CopyableText-CQapvaMr-TfbbNTSm.js";import{T as R}from"./triangle-alert-DUn1mTuV.js";import{c as F}from"./createLucideIcon-CWcIInnG.js";import{C as P}from"./check-udIDPn4r.js";import{H as we}from"./hourglass-DGGdavRx.js";import{C as Te}from"./chevron-down-DwBx7-IU.js";import{o as Ne,n as Se,s as je,p as De}from"./floating-ui.react-dom-r2Rrq6xm.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-Dq_xe9dz-CpsEonUS.js";import"./dijkstra-C00ieaqj.js";import"./copy-CUTCh4z2.js";function Ue(e,t){return o=>{e({eventName:o.eventName,payload:{...o.payload,flowId:t}})}}const x=te(()=>null),w=e=>{x.getState()!==null&&x.setState(e)};async function Ae(e,t){let o=await e.fetchPrivyRoute(oe,{}),s={config:{status:"ready",data:{currencies:o.currencies,chains:o.chains}}};t!=null&&t.aborted||w(s)}function b(){let e=x(),{closePrivyModal:t,privy:o,createAnalyticsEvent:s}=v(),a=e==null?void 0:e.flowId,l=m.useMemo(()=>a?Ue(s,a):()=>{},[s,a]),i=(e==null?void 0:e.params)??null,p=(e==null?void 0:e.config)??{status:"loading"},u=m.useCallback(c=>{let f=M(a);if(!f||(w({modalState:c}),f.modalState.step===c.step))return;l({eventName:"sdk_deposit_address_step_viewed",payload:{step:c.step,...c.step==="error"?{errorCode:c.code}:{}}});let y=function(g){switch(g.step){case"complete":return{outcome:"completed",step:"complete"};case"failed":return{outcome:"failed",step:"failed",errorCode:"DEPOSIT_FAILED"};case"refunded":return{outcome:"refunded",step:"refunded",errorCode:"DEPOSIT_REFUNDED"};default:return null}}(c);y&&l({eventName:"sdk_deposit_address_concluded",payload:y})},[l,a]),n=m.useCallback(async()=>{let c=e==null?void 0:e.controller;if(i&&c&&!c.signal.aborted){w({config:{status:"loading"}});try{await Ae(o,c.signal)}catch(f){if(c.signal.aborted)return;throw w({config:{status:"error",error:f instanceof Error?f:Error("Failed to load deposit config")}}),f}}},[i,o,e==null?void 0:e.controller]),d=m.useCallback(()=>{let c=M(a);if(!c)return;let{modalState:f}=c;l({eventName:"sdk_deposit_address_exited",payload:{step:f.step,...f.step==="error"?{errorCode:f.code}:{}}});let y=function(g){switch(g.step){case"complete":case"failed":case"refunded":return null;case"error":return{outcome:"failed",step:"error",errorCode:g.code};default:return{outcome:"abandoned",step:g.step}}}(f);y&&l({eventName:"sdk_deposit_address_concluded",payload:y}),f.step==="complete"?c.onComplete():f.step==="failed"?c.onError(Error("DEPOSIT_FAILED")):f.step==="error"?c.onError(Error(f.code)):f.step==="refunded"?c.onError(Error("DEPOSIT_REFUNDED")):c.onError(Error("USER_EXITED")),t({shouldCallAuthOnSuccess:!1})},[a,t,l]);return{modalState:(e==null?void 0:e.modalState)??{step:"intro"},setModalState:u,config:p,retryConfig:n,params:i,close:d,onBack:e==null?void 0:e.onBack,createDepositAddressEvent:l}}function M(e){let t=x.getState();return t&&t.flowId===e?t:null}function E(e){let{modalState:t,config:o,params:s,...a}=b();if(function(l,i){if(l.step!==i)throw Error("UNEXPECTED_STATE")}(t,e),!s||o.status!=="ready")throw Error("UNEXPECTED_STATE");return{state:t,configData:o.data,params:s,...a}}/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ie=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],Oe=F("chevron-up",Ie);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Re=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],Fe=F("info",Re);/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pe=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],Le=F("undo-2",Pe);class $e extends m.Component{static getDerivedStateFromError(){return{hasError:!0}}componentDidCatch(t,o){this.props.onError(t)}componentDidUpdate(t){t.resetKey!==this.props.resetKey&&this.state.hasError&&this.setState({hasError:!1})}render(){return this.state.hasError?null:this.props.children}constructor(...t){super(...t),this.state={hasError:!1}}}function Me(e,t,o){let s=Number(e);return!Number.isFinite(s)||s===0?`1 ${t} ≈ ${e} ${o}`:s>=.01?`1 ${t} ≈ ${B(s)} ${o}`:`${B(1/s)} ${t} ≈ 1 ${o}`}function B(e){return e>=1e3?new Intl.NumberFormat("en-US",{maximumFractionDigits:0}).format(Math.round(e)):e>=100?new Intl.NumberFormat("en-US",{maximumFractionDigits:1}).format(e):e>=1?new Intl.NumberFormat("en-US",{maximumFractionDigits:2}).format(e):new Intl.NumberFormat("en-US",{maximumFractionDigits:4}).format(e)}function V(e,t){let o=Number(e);if(!Number.isFinite(o)||o===0)return e;let s=t!=null?o/10**t:o;return s>=1e3?new Intl.NumberFormat("en-US",{maximumFractionDigits:2}).format(s):s>=1?new Intl.NumberFormat("en-US",{maximumFractionDigits:4}).format(s):s>=1e-4?new Intl.NumberFormat("en-US",{maximumFractionDigits:6}).format(s):new Intl.NumberFormat("en-US",{maximumSignificantDigits:4}).format(s)}function I({address:e,caip2:t,config:o}){for(let s of o.currencies){let a=s.chains.find(l=>l.caip2===t&&l.address.toLowerCase()===e.toLowerCase());if(a)return{symbol:s.symbol.toUpperCase(),decimals:a.decimals}}return{symbol:e,decimals:void 0}}function z(e,t){var o;return((o=t[e])==null?void 0:o.displayName)??e}function W(e,t){return e.chains.filter(o=>o.can_be_relay_deposit_source===!0).map(o=>{let s=t.chains[o.caip2];return s?{caip2:o.caip2,displayName:s.displayName,iconUrl:s.iconUrl,vmType:s.vmType,currencyAddress:o.address,currencyDecimals:o.decimals}:null}).filter(o=>o!==null)}function q(e,t){if(!e.chains[t.destinationChain])return`Unsupported destination chain: "${t.destinationChain}". Check that the chain is in CAIP-2 format (e.g. "eip155:8453") and is supported for deposit addresses.`;let o=t.destinationCurrency.toLowerCase();return e.currencies.some(s=>s.chains.some(a=>a.caip2===t.destinationChain&&a.address.toLowerCase()===o))?null:`Unsupported destination currency "${t.destinationCurrency}" on chain "${t.destinationChain}". Check that this token address is supported on the specified chain.`}let Be=new Set(["ROUTE_UNAVAILABLE","UNEXPECTED_STATE","TIMEOUT_WAITING_FOR_NEXT_ORDER","TIMEOUT_ORDER_COMPLETION","DEPOSIT_FAILED","DEPOSIT_REFUNDED","USER_EXITED","AMOUNT_TOO_LOW","INSUFFICIENT_LIQUIDITY","UNSUPPORTED_CHAIN","UNSUPPORTED_CURRENCY","UNSUPPORTED_ROUTE","NO_SWAP_ROUTES_FOUND","NO_INTERNAL_SWAP_ROUTES_FOUND","NO_QUOTES","SANCTIONED_WALLET_ADDRESS","REFUND_WALLET_CREATION_FAILED","DEPOSIT_ADDRESSES_NOT_ENABLED","NOT_AUTHENTICATED"]);function Ve(e){return Be.has(e)}function Q(e){return Ve(e)?e:"UNKNOWN_ERROR"}function ee(){let{params:e,setModalState:t}=b(),{privy:o}=v(),s=function(){let{privy:i,refreshSessionAndUser:p}=v();return m.useCallback((u,n)=>n?Promise.resolve({ok:!0,address:n}):O.resolveRefundAddress({privy:i,caip2:u,onWalletCreated:p}),[i,p])}(),[a,l]=m.useState(!1);return{fetchQuote:m.useCallback(async(i,p,u)=>{if(e){l(!0);try{let n=await s(i.caip2,e.refundAddress);if(!n.ok)return void t({step:"error",code:Q(n.error)});let d=await o.fetchPrivyRoute(ae,{body:{source_chain:i.caip2,source_currency:i.currencyAddress,destination_chain:e.destinationChain,destination_currency:e.destinationCurrency,destination_address:e.destinationAddress,refund_address:n.address,...e.slippageBps!=null?{slippage_bps:e.slippageBps}:{}}});t({step:"address",selectedCurrency:p,selectedChain:i,availableChains:u,quote:d})}catch(n){let d=n instanceof Error?n:Error(String(n)),c="status"in d&&typeof d.status=="number"?d.status:void 0;t({step:"error",code:d instanceof ie&&d.code==="feature_not_enabled"?"DEPOSIT_ADDRESSES_NOT_ENABLED":c&&c>=500?"UNKNOWN_ERROR":Q(d.message),message:d.message})}finally{l(!1)}}},[e,o,s,t]),isFetching:a}}function re(e,t){switch(e.status){case"completed":return t({step:"complete",order:e});case"refunded":return t({step:"refunded",order:e});case"failed":return t({step:"failed",order:e});case"executing":return t({step:"processing",order:e});default:return}}const ze=({sourceAmount:e,sourceSymbol:t,sourceChainName:o,sourceDecimals:s,destinationAmount:a,destSymbol:l,destChainName:i,destDecimals:p,onClose:u})=>r.jsx(T,{icon:P,iconVariant:"success",title:"Transfer complete",subtitle:a?`Received ${V(e,s)} ${t} on ${o} and converted it to ${V(a,p)} ${l} on ${i}. Funds are available to use.`:`Your ${t} has been received and is now available in your wallet.`,showClose:!0,onClose:u,primaryCta:{label:"Done",onClick:u},watermark:!1});function We(){let{state:e,configData:t,close:o}=E("complete"),{order:s}=e,{sourceSymbol:a,sourceChainName:l,sourceDecimals:i,destSymbol:p,destChainName:u,destDecimals:n}=m.useMemo(()=>{let d=I({address:s.source_currency,caip2:s.source_chain,config:t}),c=I({address:s.destination_currency,caip2:s.destination_chain,config:t});return{sourceSymbol:d.symbol,sourceChainName:z(s.source_chain,t.chains),sourceDecimals:d.decimals,destSymbol:c.symbol,destChainName:z(s.destination_chain,t.chains),destDecimals:c.decimals}},[s,t]);return r.jsx(ze,{sourceAmount:s.source_amount,sourceSymbol:a,sourceChainName:l,sourceDecimals:i,destinationAmount:s.destination_amount,destSymbol:p,destChainName:u,destDecimals:n,onClose:o})}function qe(){let{modalState:e,setModalState:t,config:o,retryConfig:s,close:a,createDepositAddressEvent:l}=b();if(e.step!=="error")throw Error("UNEXPECTED_STATE");let{code:i}=e,{title:p,subtitle:u,detail:n,iconVariant:d}=(y=>{switch(y){case"AMOUNT_TOO_LOW":return{title:"Amount too low",subtitle:"The deposit amount is below the minimum for this route.",detail:"Try a larger amount or a different token.",iconVariant:"warning"};case"INSUFFICIENT_LIQUIDITY":return{title:"Insufficient liquidity",subtitle:"There isn't enough liquidity for this route right now.",detail:"Try a smaller amount or a different network.",iconVariant:"warning"};case"UNSUPPORTED_CHAIN":return{title:"Unsupported chain",subtitle:"Deposits from this chain type aren't supported yet. Try a different network.",iconVariant:"warning"};case"UNSUPPORTED_CURRENCY":case"UNSUPPORTED_ROUTE":case"ROUTE_UNAVAILABLE":case"NO_SWAP_ROUTES_FOUND":case"NO_INTERNAL_SWAP_ROUTES_FOUND":case"NO_QUOTES":return{title:"Route not available",subtitle:"This deposit route isn't supported right now. Try a different token or network.",iconVariant:"warning"};case"SANCTIONED_WALLET_ADDRESS":return{title:"Address restricted",subtitle:"This address cannot be used for deposits due to compliance restrictions.",iconVariant:"warning"};case"REFUND_WALLET_CREATION_FAILED":return{title:"Unable to set up refund address",subtitle:"We couldn't create a wallet to receive refunds on this chain. Please try again or select a different network.",iconVariant:"warning"};case"DEPOSIT_ADDRESSES_NOT_ENABLED":return{title:"Not enabled",subtitle:"Deposit addresses are not enabled for this app.",iconVariant:"warning"};case"NOT_AUTHENTICATED":return{title:"Not signed in",subtitle:"Please sign in to continue with your deposit.",iconVariant:"warning"};case"TIMEOUT_WAITING_FOR_NEXT_ORDER":case"TIMEOUT_ORDER_COMPLETION":return{title:"Taking longer than expected",subtitle:"Your funds are safe. The deposit is still being processed — check back later.",iconVariant:"subtle"};default:return{title:"Something went wrong",subtitle:"We couldn't complete your request. Please try again.",iconVariant:"subtle"}}})(i),[c,f]=m.useState(!1);return r.jsx(T,{icon:R,iconVariant:d,title:p,subtitle:n?`${u} ${n}`:u,showClose:!0,onClose:a,primaryCta:{label:"Try again",onClick:async()=>{if(l({eventName:"sdk_deposit_address_action",payload:{action:"retry",step:"error",errorCode:i}}),o.status!=="ready"){f(!0);try{await s(),t({step:"token"})}catch{f(!1)}}else t({step:"token"})},loading:c},watermark:!0})}function Qe(){let{state:e,close:t,createDepositAddressEvent:o}=E("failed"),{order:s}=e;return r.jsx(k,{icon:R,iconVariant:"error",title:"Transfer failed",subtitle:"Something went wrong processing your transfer.",showClose:!0,onClose:t,primaryCta:{label:"Done",onClick:t},secondaryCta:{label:"Learn about manual recovery",onClick:()=>{o({eventName:"sdk_deposit_address_action",payload:{action:"link_opened",step:"failed",target:"recovery_docs"}}),window.open("https://docs.privy.io","_blank","noopener,noreferrer")}},watermark:!0,children:r.jsxs(Xe,{href:s.tracking_url,target:"_blank",rel:"noopener noreferrer",onClick:()=>{o({eventName:"sdk_deposit_address_action",payload:{action:"link_opened",step:"failed",target:"relay_reference"}})},children:["Reference: ",s.provider_request_id]})})}let Xe=h.a`
  text-align: center;
  font-size: 0.75rem;
  opacity: 0.7;
  text-decoration: underline;
  cursor: pointer;
  color: var(--privy-color-foreground-3);
`;function Ye(){let{close:e,setModalState:t,config:o,params:s,onBack:a,createDepositAddressEvent:l}=b(),[i,p]=m.useState(!1);return m.useEffect(()=>{if(i&&s){if(o.status==="ready"){let u=q(o.data,s);t(u?{step:"error",code:"ROUTE_UNAVAILABLE",message:u}:{step:"token"})}o.status==="error"&&t({step:"error",code:"ROUTE_UNAVAILABLE"})}},[i,o,s,t]),r.jsx(T,{icon:J,iconVariant:"subtle",title:"Add funds",subtitle:"Top up your account by sending crypto from any wallet. Conversion and routing handled by Relay.",showClose:!0,onClose:e,showBack:!!a,onBack:a?()=>{l({eventName:"sdk_deposit_address_action",payload:{action:"back",step:"intro"}}),a()}:void 0,primaryCta:{label:"Continue",onClick:()=>{if(l({eventName:"sdk_deposit_address_action",payload:{action:"continue",step:"intro"}}),o.status==="ready"&&s){let u=q(o.data,s);t(u?{step:"error",code:"ROUTE_UNAVAILABLE",message:u}:{step:"token"})}else o.status==="error"?t({step:"error",code:"ROUTE_UNAVAILABLE"}):p(!0)},loading:i&&o.status==="loading",loadingText:null},watermark:!0})}function He(){let{state:e,setModalState:t,close:o,createDepositAddressEvent:s}=E("network"),[a,l]=m.useState(-1),{availableChains:i}=e,{confirm:p,isFetching:u}=function(){let n=x(),{params:d}=b(),{fetchQuote:c,isFetching:f}=ee();return{confirm:m.useCallback(async y=>{if(!y||!d)return;let g=n==null?void 0:n.modalState;g&&g.step==="network"&&await c(y,g.selectedCurrency,g.availableChains)},[d,n,c]),isFetching:f}}();return r.jsx(k,{title:"Select network",eyebrow:r.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"0.375rem"},children:[r.jsx("img",{src:e.selectedCurrency.logoURI,alt:"",style:{width:"1rem",height:"1rem",borderRadius:"50%"}}),"Send ",e.selectedCurrency.symbol]}),showBack:!0,onBack:()=>{s({eventName:"sdk_deposit_address_action",payload:{action:"back",step:"network"}}),t({step:"token"})},showClose:!0,onClose:o,watermark:!0,children:r.jsx(Z,{style:{marginTop:"1rem",height:"22rem"},$colorScheme:"light",children:i.map((n,d)=>r.jsxs(X,{$selected:a===d,disabled:u,onClick:()=>{s({eventName:"sdk_deposit_address_action",payload:{action:"network_selected",step:"network",network:n.caip2}}),l(d),p(n)},children:[r.jsx(Y,{src:n.iconUrl,alt:n.displayName}),r.jsx(H,{children:n.displayName}),u&&d===a&&r.jsx(K,{})]},n.caip2))})})}const Ke=({trackingUrl:e,onViewBlockExplorer:t,onClose:o})=>r.jsx(k,{icon:we,iconVariant:"subtle",title:"Transfer in progress",subtitle:"Your deposit was received and the transfer is now processing.",showClose:!0,onClose:o,secondaryCta:{label:"View on block explorer ↗",onClick:()=>{t(),window.open(e,"_blank","noopener,noreferrer")}},watermark:!1,children:r.jsxs(ue,{children:[r.jsxs(N,{children:[r.jsx(S,{$status:"done",children:r.jsx(P,{size:14,color:"var(--privy-color-icon-success)",strokeWidth:2})}),r.jsx(j,{children:"Deposit received"})]}),r.jsx($,{}),r.jsxs(N,{children:[r.jsx(S,{$status:"active",children:r.jsx(Ge,{})}),r.jsx(j,{children:"Bridging"})]}),r.jsx($,{}),r.jsxs(N,{children:[r.jsx(S,{$status:"pending"}),r.jsx(j,{children:"Funds arrived"})]})]})});let Ge=h.span`
  width: 0.75rem;
  height: 0.75rem;
  border: 2px solid var(--privy-color-foreground-3);
  border-bottom-color: transparent;
  border-radius: 50%;
  display: inline-block;
  animation: spin 1s linear infinite;

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`;function Je(){let{state:e,close:t,createDepositAddressEvent:o}=E("processing");return function({orderId:s,enabled:a}){let{privy:l}=v(),{setModalState:i}=b();m.useEffect(()=>{let p=new AbortController;return O.waitForCompletion({privy:l,orderId:s,signal:p.signal}).then(u=>{p.signal.aborted||(u.status==="success"?re(u.order,i):u.status==="timeout"&&i({step:"error",code:"TIMEOUT_ORDER_COMPLETION"}))}),()=>{p.abort()}},[a,s,l,i])}({orderId:e.order.id,enabled:!0}),r.jsx(Ke,{trackingUrl:e.order.tracking_url,onViewBlockExplorer:()=>{o({eventName:"sdk_deposit_address_action",payload:{action:"link_opened",step:"processing",target:"block_explorer"}})},onClose:t})}function Ze(){let{state:e,close:t,createDepositAddressEvent:o}=E("refunded"),{order:s}=e;return r.jsx(T,{icon:Le,iconVariant:"subtle",title:"Transfer refunded",subtitle:"Your transfer was received, but the swap couldn't be completed. A refund has been started automatically.",showClose:!0,onClose:t,primaryCta:{label:"Done",onClick:t},secondaryCta:{label:"View transaction details",onClick:()=>{o({eventName:"sdk_deposit_address_action",payload:{action:"link_opened",step:"refunded",target:"transaction_details"}}),window.open(s.tracking_url,"_blank","noopener,noreferrer")}},watermark:!0})}function er(){let{close:e,setModalState:t,config:o,createDepositAddressEvent:s}=b(),{confirm:a,currencies:l,isFetching:i}=function(){let{config:n,setModalState:d}=b(),{fetchQuote:c,isFetching:f}=ee(),y=n.status==="ready"?n.data.currencies.filter(g=>W(g,n.data).length>0):[];return{confirm:m.useCallback(async g=>{if(n.status!=="ready"||!g)return;let _=W(g,n.data);if(_.length!==1)d({step:"network",selectedCurrency:g,availableChains:_});else{let C=_[0];await c(C,g,_)}},[n,c,d]),currencies:y,isFetching:f}}(),[p,u]=m.useState(-1);return r.jsx(k,{title:"Select token",showBack:!0,onBack:()=>{s({eventName:"sdk_deposit_address_action",payload:{action:"back",step:"token"}}),t({step:"intro"})},showClose:!0,onClose:e,watermark:!0,children:o.status==="error"?r.jsx(L,{children:r.jsx(de,{children:"Failed to load tokens"})}):o.status==="loading"?r.jsx(L,{children:r.jsx(ne,{})}):r.jsx(Z,{style:{marginTop:"1rem",height:"22rem"},$colorScheme:"light",children:l.map((n,d)=>r.jsxs(X,{$selected:p===d,disabled:i,onClick:()=>{s({eventName:"sdk_deposit_address_action",payload:{action:"token_selected",step:"token",token:n.symbol}}),u(d),a(n)},children:[r.jsx(G,{src:n.logoURI,alt:n.symbol}),r.jsx(H,{children:n.name}),i&&d===p?r.jsx(K,{}):r.jsx(ce,{children:n.symbol})]},n.symbol))})})}function rr({address:e,onClick:t}){let[o,s]=m.useState(!1);return r.jsx(r.Fragment,{children:o?r.jsx(tr,{onClick:()=>s(!1),style:{marginTop:"1.5rem"},children:r.jsx(me,{url:e,size:312,hideLogo:!0})}):r.jsxs(or,{title:"Click to copy address",onClick:t,style:{marginTop:"1.5rem"},children:[r.jsxs(sr,{children:[r.jsx(nr,{children:"Deposit address"}),r.jsx(ar,{children:e})]}),r.jsx(ir,{children:r.jsx(lr,{type:"button",onClick:a=>{a.stopPropagation(),s(!0)},children:r.jsx(J,{size:16,color:"var(--privy-color-icon-muted)"})})})]})})}let tr=h.div`
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  overflow: hidden;
`,or=h.div`
  display: flex;
  border-radius: var(--privy-border-radius-md);
  background: var(--privy-color-background-clicked, #f1f2f9);
  padding: 1rem;
  cursor: pointer;
  gap: 0.5rem;
`,sr=h.div`
  flex: 1;
  min-width: 0;
  text-align: left;
`,nr=h.div`
  font-size: 0.75rem;
  color: var(--privy-color-icon-muted);
  line-height: 1rem;
  margin-bottom: 0.25rem;
`,ar=h.div`
  word-break: break-all;
  font-size: 0.875rem;
  font-family: ui-monospace, monospace;
  font-weight: 500;
  line-height: 1.375rem;
  color: var(--privy-color-foreground);
`,ir=h.div`
  width: 1.5rem;
  flex-shrink: 0;
  display: flex;
  justify-content: center;
  padding-top: 0.25rem;
`,lr=h.button`
  && {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.5rem;
    height: 1.5rem;
    border: none;
    background: transparent;
    cursor: pointer;
    outline: none;
    box-shadow: none;
    border-radius: var(--privy-border-radius-xs);

    &:hover {
      background: var(--privy-color-background);
    }

    &:focus,
    &:focus-visible {
      outline: none;
      box-shadow: none;
    }
  }
`;function dr({quote:e,selectedCurrency:t,selectedChain:o,destinationSymbol:s}){let[a,l]=m.useState(!1),i=t.symbol.toUpperCase(),p=o.displayName,u=m.useRef(null);return r.jsxs(cr,{children:[r.jsxs(ur,{onClick:m.useCallback(()=>{let n=document.getElementById("privy-modal-content");n&&(u.current&&clearTimeout(u.current),n.style.transition="none",u.current=setTimeout(()=>{n.style.transition="",u.current=null},160)),l(d=>!d)},[]),children:[r.jsxs(pr,{children:[t.logoURI&&r.jsx(G,{src:t.logoURI,alt:i,style:{width:"2rem",height:"2rem"}}),o.iconUrl&&r.jsx(mr,{src:o.iconUrl,alt:p})]}),r.jsxs(fr,{children:[r.jsx(hr,{children:"You send"}),r.jsxs(gr,{children:[i," on ",p]})]}),r.jsx(yr,{children:r.jsx(a?Oe:Te,{size:16})})]}),r.jsx(Er,{$expanded:a,children:r.jsx(Cr,{children:r.jsxs(br,{children:[e.indicative_rate&&r.jsxs(D,{children:[r.jsx(U,{children:"Conversion rate"}),r.jsxs(A,{style:{display:"flex",alignItems:"center",gap:"0.25rem"},children:[Me(e.indicative_rate,i,s.toUpperCase()),r.jsx(vr,{content:"Estimated rate based on current market conditions. Final execution price may vary depending on transfer size and routing."})]})]}),r.jsxs(D,{children:[r.jsx(U,{children:"Max slippage"}),r.jsxs(A,{children:[(e.slippage_bps/100).toFixed(1),"%"]})]}),r.jsxs(D,{children:[r.jsx(U,{children:"Refund address"}),r.jsx(A,{children:r.jsx(ke,{value:e.refund_address,iconOnly:!0,iconSize:11,children:le(e.refund_address,4,4)})})]})]})})}),r.jsxs(_r,{children:[r.jsx(R,{size:16,color:"var(--privy-color-icon-muted)",style:{flexShrink:0}}),r.jsxs(xr,{children:["Only send ",r.jsx("strong",{children:i})," on ",r.jsx("strong",{children:p}),". Other assets may be lost."]})]})]})}let cr=h.div`
  border-radius: var(--privy-border-radius-md);
  border: 1px solid var(--privy-color-foreground-4);
  overflow: hidden;
`,ur=h.button`
  && {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
    background: transparent;
    border: none;
    cursor: pointer;
    color: var(--privy-color-foreground);
    outline: none;
    box-shadow: none;

    &:focus,
    &:focus-visible {
      outline: none;
      box-shadow: none;
    }
  }
`,pr=h.span`
  position: relative;
  width: 2rem;
  height: 2rem;
  flex-shrink: 0;
`,mr=h(Y)`
  && {
    position: absolute;
    top: -0.125rem;
    right: -0.25rem;
    width: 0.75rem;
    height: 0.75rem;
    box-sizing: content-box;
    border: 1.5px solid #fff;
    background-color: #fff;
  }
`,fr=h.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
`,hr=h.span`
  font-size: 0.75rem;
  color: var(--privy-color-foreground-3);
  line-height: 1rem;
`,gr=h.span`
  font-size: 0.875rem;
  font-weight: 500;
  line-height: 1.25rem;
`,yr=h.span`
  margin-left: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 1.5rem;
  height: 1.5rem;
  border-radius: var(--privy-border-radius-full);
  background-color: var(--privy-color-background-clicked, #f1f2f9);
  color: var(--privy-color-foreground-3);
`,br=h.div`
  display: flex;
  flex-direction: column;
  padding: 0 1rem 0.75rem;

  & > * {
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--privy-color-foreground-4);
  }

  & > *:last-child {
    border-bottom: none;
  }
`,_r=h.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 0.75rem 0.75rem;
  padding: 0.625rem 0.75rem;
  border-radius: var(--privy-border-radius-sm);
  background: #f8f9fc;
`,xr=h.span`
  font-size: 0.8125rem;
  line-height: 1.25rem;
  color: var(--privy-color-icon-muted);
  text-align: left;
`,Er=h.div`
  display: grid;
  grid-template-rows: ${({$expanded:e})=>e?"1fr":"0fr"};
  transition: grid-template-rows 150ms ease-out;
`,Cr=h.div`
  overflow: hidden;
`;function vr({content:e}){let[t,o]=m.useState(!1),{refs:s,floatingStyles:a,context:l}=fe({open:t,onOpenChange:o,placement:"top",whileElementsMounted:De,middleware:[Ne(6),Se(),je({padding:8})]}),i=he(l,{move:!1,handleClose:ge()}),p=ye(l),{getReferenceProps:u,getFloatingProps:n}=be([i,p,_e(l),xe(l),Ee(l,{role:"tooltip"})]),{isMounted:d,styles:c}=Ce(l,{duration:150});return r.jsxs(r.Fragment,{children:[r.jsx("button",{ref:s.setReference,type:"button","aria-label":"More information about conversion rate",style:{display:"inline-flex",alignItems:"center",justifyContent:"center",padding:0,border:"none",background:"none",color:"var(--privy-color-icon-muted)",cursor:"pointer"},...u(),children:r.jsx(Fe,{size:14})}),d&&r.jsx(ve,{root:document.getElementById("privy-modal-content")??void 0,children:r.jsx(kr,{ref:s.setFloating,style:{...a,...c},...n(),children:e})})]})}let kr=h.div`
  max-width: 13rem;
  padding: 0.5rem 0.625rem;
  border-radius: var(--privy-border-radius-sm, 0.375rem);
  background: var(--privy-color-foreground);
  color: var(--privy-color-background);
  font-size: 0.6875rem;
  line-height: 1rem;
  font-weight: 400;
  text-align: left;
  z-index: 10;
`;const wr=({quote:e,selectedCurrency:t,selectedChain:o,destinationSymbol:s,onBack:a,onClose:l})=>{var c;let[i,p]=m.useState(!1),u=((c=t==null?void 0:t.symbol)==null?void 0:c.toUpperCase())??"funds",n=(o==null?void 0:o.displayName)??"",d=async()=>{i||(await navigator.clipboard.writeText(e.deposit_address),p(!0),setTimeout(()=>p(!1),2e3))};return r.jsxs(k,{title:`Send ${u}${n?` on ${n}`:""}`,subtitle:"Send funds to the address below. Conversion and routing handled by Relay.",showBack:!0,onBack:a,showClose:!0,onClose:l,watermark:!1,children:[r.jsx(dr,{quote:e,selectedCurrency:t,selectedChain:o,destinationSymbol:s}),r.jsx(rr,{address:e.deposit_address,onClick:d}),r.jsx(pe,{style:{marginTop:"1rem",marginBottom:"0.5rem",...i?{backgroundColor:"var(--privy-color-icon-success)",borderColor:"var(--privy-color-icon-success)"}:{}},onClick:d,children:i?r.jsxs(r.Fragment,{children:["Copied ",r.jsx(P,{size:16,style:{marginLeft:"0.25rem"}})]}):"Copy address"}),r.jsx(Tr,{children:"Routing and bridging are handled by Relay. Privy does not control execution timing, liquidity, or transaction outcomes."})]})};let Tr=h.p`
  && {
    margin: 0.5rem 0 0;
    font-size: 0.6875rem;
    line-height: 1.125rem;
    color: var(--privy-color-icon-muted);
    text-align: center;
  }
`;function Nr(){let{state:e,configData:t,setModalState:o,close:s,params:a,createDepositAddressEvent:l}=E("address"),{quote:i,selectedCurrency:p,selectedChain:u,availableChains:n}=e;return function({depositAddressId:d,enabled:c,quoteCreatedAt:f}){let{privy:y}=v(),{setModalState:g}=b();m.useEffect(()=>{if(!d)return;let _=new AbortController;return O.waitForDeposit({privy:y,depositAddressId:d,quoteCreatedAt:f,signal:_.signal}).then(C=>{_.signal.aborted||(C.status==="success"?re(C.order,g):C.status==="timeout"&&g({step:"error",code:"TIMEOUT_WAITING_FOR_NEXT_ORDER"}))}),()=>{_.abort()}},[c,d,y,f,g])}({depositAddressId:i.id,enabled:!0,quoteCreatedAt:i.created_at}),r.jsx(wr,{quote:i,selectedCurrency:p,selectedChain:u,destinationSymbol:m.useMemo(()=>I({address:a.destinationCurrency,caip2:a.destinationChain,config:t}).symbol,[a,t]),onBack:()=>{l({eventName:"sdk_deposit_address_action",payload:{action:"back",step:"address"}}),o({step:"network",selectedCurrency:p,availableChains:n})},onClose:s})}function Sr(){let{modalState:e,setModalState:t}=b();return r.jsx($e,{onError:o=>t({step:"error",code:"UNEXPECTED_STATE",message:o.message}),resetKey:e.step,children:r.jsx(jr,{})})}function jr(){let{modalState:e}=b();switch(e.step){case"intro":return r.jsx(Ye,{});case"token":return r.jsx(er,{});case"network":return r.jsx(He,{});case"address":return r.jsx(Nr,{});case"processing":return r.jsx(Je,{});case"complete":return r.jsx(We,{});case"refunded":return r.jsx(Ze,{});case"failed":return r.jsx(Qe,{});case"error":return r.jsx(qe,{});default:return null}}var Jr={component:()=>{let{onUserCloseViaDialogOrKeybindRef:e}=se(),t=x(),{close:o,config:s}=b();return m.useEffect(()=>{e.current=o},[e,o]),m.useEffect(()=>{if(s.status==="ready"){for(let a of s.data.currencies)new Image().src=a.logoURI;for(let a of Object.values(s.data.chains))new Image().src=a.iconUrl}},[s]),t?r.jsx(Sr,{}):null}};export{Jr as default};
