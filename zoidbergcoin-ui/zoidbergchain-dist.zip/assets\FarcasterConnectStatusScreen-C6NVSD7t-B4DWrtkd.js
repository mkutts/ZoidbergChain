import{d4 as t,dG as X,d5 as Y,d6 as Z,d7 as ee,da as u,dP as re,dC as $,dE as F,dz as te,dy as n}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as l}from"./index-6mJiZeaw.js";import{n as ae}from"./OpenLink-DZHy38vr-Det0LaNF.js";import{C as ie}from"./QrCode-CQ-0kWFq-CW2WL8os.js";import{$ as oe}from"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import{r as ne}from"./LabelXs-oqZNqbm_-CyO8h7Kr.js";import{a as se}from"./shouldProceedtoEmbeddedWalletCreationFlow-CFYHLuSq-CTl6mGyV.js";import{n as le}from"./ScreenLayout-BMEsmxmC-DRwMW8Lv.js";import{l as O}from"./farcaster-DPlSjvF5-DgzPInmD.js";import{C as ce}from"./check-udIDPn4r.js";import{C as de}from"./copy-CUTCh4z2.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./dijkstra-C00ieaqj.js";import"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-Dq_xe9dz-CpsEonUS.js";import"./createLucideIcon-CWcIInnG.js";let ue=n.div`
  width: 100%;
`,pe=n.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  padding: 0.75rem;
  height: 56px;
  background: ${r=>r.$disabled?"var(--privy-color-background-2)":"var(--privy-color-background)"};
  border: 1px solid var(--privy-color-foreground-4);
  border-radius: var(--privy-border-radius-md);

  &:hover {
    border-color: ${r=>r.$disabled?"var(--privy-color-foreground-4)":"var(--privy-color-foreground-3)"};
  }
`,me=n.div`
  flex: 1;
  min-width: 0;
  display: flex;
  align-items: center;
`,Q=n.span`
  display: block;
  font-size: 16px;
  line-height: 24px;
  color: ${r=>r.$disabled?"var(--privy-color-foreground-2)":"var(--privy-color-foreground)"};
  overflow: hidden;
  text-overflow: ellipsis;
  /* Use single-line truncation without nowrap to respect container width */
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  word-break: break-all;

  @media (min-width: 441px) {
    font-size: 14px;
    line-height: 20px;
  }
`,he=n(Q)`
  color: var(--privy-color-foreground-3);
  font-style: italic;
`,fe=n(ne)`
  margin-bottom: 0.5rem;
`,ge=n(oe)`
  && {
    gap: 0.375rem;
    font-size: 14px;
    flex-shrink: 0;
  }
`;const ve=({value:r,title:p,placeholder:c,className:a,showCopyButton:d=!0,truncate:o,maxLength:m=40,disabled:h=!1})=>{let[s,x]=l.useState(!1),w=o&&r?((i,S,f)=>{if((i=i.startsWith("https://")?i.slice(8):i).length<=f)return i;if(S==="middle"){let y=Math.ceil(f/2)-2,C=Math.floor(f/2)-1;return`${i.slice(0,y)}...${i.slice(-C)}`}return`${i.slice(0,f-3)}...`})(r,o,m):r;return l.useEffect(()=>{if(s){let i=setTimeout(()=>x(!1),3e3);return()=>clearTimeout(i)}},[s]),t.jsxs(ue,{className:a,children:[p&&t.jsx(fe,{children:p}),t.jsxs(pe,{$disabled:h,children:[t.jsx(me,{children:r?t.jsx(Q,{$disabled:h,title:r,children:w}):t.jsx(he,{$disabled:h,children:c||"No value"})}),d&&r&&t.jsx(ge,{onClick:function(i){i.stopPropagation(),navigator.clipboard.writeText(r).then(()=>x(!0)).catch(console.error)},size:"sm",children:t.jsxs(t.Fragment,s?{children:["Copied",t.jsx(ce,{size:14})]}:{children:["Copy",t.jsx(de,{size:14})]})})]})]})},xe=({connectUri:r,loading:p,success:c,errorMessage:a,onBack:d,onClose:o,onOpenFarcaster:m})=>t.jsx(le,F.isMobile||p?F.isIOS?{title:a?a.message:"Sign in with Farcaster",subtitle:a?a.detail:"To sign in with Farcaster, please open the Farcaster app.",icon:O,iconVariant:"loading",iconLoadingStatus:{success:c,fail:!!a},primaryCta:r&&m?{label:"Open Farcaster app",onClick:m}:void 0,onBack:d,onClose:o,watermark:!0}:{title:a?a.message:"Signing in with Farcaster",subtitle:a?a.detail:"This should only take a moment",icon:O,iconVariant:"loading",iconLoadingStatus:{success:c,fail:!!a},onBack:d,onClose:o,watermark:!0,children:r&&F.isMobile&&t.jsx(ye,{children:t.jsx(ae,{text:"Take me to Farcaster",url:r,color:"#8a63d2"})})}:{title:"Sign in with Farcaster",subtitle:"Scan with your phone's camera to continue.",onBack:d,onClose:o,watermark:!0,children:t.jsxs(be,{children:[t.jsx(Ee,{children:r?t.jsx(ie,{url:r,size:275,squareLogoElement:O}):t.jsx(Ce,{children:t.jsx(te,{})})}),t.jsxs(we,{children:[t.jsx(Se,{children:"Or copy this link and paste it into a phone browser to open the Farcaster app."}),r&&t.jsx(ve,{value:r,truncate:"end",maxLength:30,showCopyButton:!0,disabled:!0})]})]})}),qe={component:()=>{let{authenticated:r,logout:p,ready:c,user:a}=X(),{lastScreen:d,navigate:o,navigateBack:m,setModalData:h}=Y(),s=Z(),{getAuthFlow:x,loginWithFarcaster:w,closePrivyModal:i,createAnalyticsEvent:S}=ee(),[f,y]=l.useState(void 0),[C,G]=l.useState(!1),[b,J]=l.useState(!1),T=l.useRef([]),E=x(),k=E==null?void 0:E.meta.connectUri;return l.useEffect(()=>{let g=Date.now(),j=setInterval(async()=>{var _,R,I,L,N,U,M,D,z,W,B,q,P,V,H;let A=await E.pollForReady.execute(),K=Date.now()-g;if(A){clearInterval(j),G(!0);try{await w(),J(!0)}catch(e){let v={retryable:!1,message:"Authentication failed"};if((e==null?void 0:e.privyErrorCode)===u.ALLOWLIST_REJECTED)return void o("AllowlistRejectionScreen");if((e==null?void 0:e.privyErrorCode)===u.USER_LIMIT_REACHED)return console.error(new re(e).toString()),void o("UserLimitReachedScreen");if((e==null?void 0:e.privyErrorCode)===u.USER_DOES_NOT_EXIST)return void o("AccountNotFoundScreen");if((e==null?void 0:e.privyErrorCode)===u.LINKED_TO_ANOTHER_USER)v.detail=e.message??"This account has already been linked to another user.";else{if((e==null?void 0:e.privyErrorCode)===u.ACCOUNT_TRANSFER_REQUIRED&&((R=(_=e.data)==null?void 0:_.data)!=null&&R.nonce))return h({accountTransfer:{nonce:(L=(I=e.data)==null?void 0:I.data)==null?void 0:L.nonce,account:(U=(N=e.data)==null?void 0:N.data)==null?void 0:U.subject,displayName:(z=(D=(M=e.data)==null?void 0:M.data)==null?void 0:D.account)==null?void 0:z.displayName,linkMethod:"farcaster",embeddedWalletAddress:(q=(B=(W=e.data)==null?void 0:W.data)==null?void 0:B.otherUser)==null?void 0:q.embeddedWalletAddress,farcasterEmbeddedAddress:(H=(V=(P=e.data)==null?void 0:P.data)==null?void 0:V.otherUser)==null?void 0:H.farcasterEmbeddedAddress}}),void o("LinkConflictScreen");(e==null?void 0:e.privyErrorCode)===u.INVALID_CREDENTIALS?(v.retryable=!0,v.detail="Something went wrong. Try again."):(e==null?void 0:e.privyErrorCode)===u.TOO_MANY_REQUESTS&&(v.detail="Too many requests. Please wait before trying again.")}y(v)}}else K>12e4&&(clearInterval(j),y({retryable:!0,message:"Authentication failed",detail:"The request timed out. Try again."}))},2e3);return()=>{clearInterval(j),T.current.forEach(A=>clearTimeout(A))}},[]),l.useEffect(()=>{if(c&&r&&b&&a){if(s!=null&&s.legal.requireUsersAcceptTerms&&!a.hasAcceptedTerms){let g=setTimeout(()=>{o("AffirmativeConsentScreen")},$);return()=>clearTimeout(g)}b&&(se(a,s.embeddedWallets)?T.current.push(setTimeout(()=>{h({createWallet:{onSuccess:()=>{},onFailure:g=>{console.error(g),S({eventName:"embedded_wallet_creation_failure_logout",payload:{error:g,screen:"FarcasterConnectStatusScreen"}}),p()},callAuthOnSuccessOnClose:!0}}),o("EmbeddedWalletOnAccountCreateScreen")},$)):T.current.push(setTimeout(()=>i({shouldCallAuthOnSuccess:!0,isSuccess:!0}),$)))}},[b,c,r,a]),t.jsx(xe,{connectUri:k,loading:C,success:b,errorMessage:f,onBack:d?m:void 0,onClose:i,onOpenFarcaster:()=>{k&&(window.location.href=k)}})}};let ye=n.div`
  margin-top: 24px;
`,be=n.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
`,Ee=n.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 275px;
`,we=n.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
`,Se=n.div`
  font-size: 0.875rem;
  text-align: center;
  color: var(--privy-color-foreground-2);
`,Ce=n.div`
  position: relative;
  width: 82px;
  height: 82px;
`;export{qe as FarcasterConnectStatusScreen,xe as FarcasterConnectStatusView,qe as default};
