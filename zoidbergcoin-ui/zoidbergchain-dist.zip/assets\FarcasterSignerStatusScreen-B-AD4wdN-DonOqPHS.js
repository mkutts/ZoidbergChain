import{d4 as t,d5 as F,d6 as T,d7 as I,dC as k,dE as x,dz as E,dy as n}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as d}from"./index-6mJiZeaw.js";import{h as O}from"./CopyToClipboard-DSTf_eKU-B6BaLONm.js";import{n as q}from"./OpenLink-DZHy38vr-Det0LaNF.js";import{C as B}from"./QrCode-CQ-0kWFq-CW2WL8os.js";import{n as _}from"./ScreenLayout-BMEsmxmC-DRwMW8Lv.js";import{l as h}from"./farcaster-DPlSjvF5-DgzPInmD.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./dijkstra-C00ieaqj.js";import"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-Dq_xe9dz-CpsEonUS.js";let S="#8a63d2";const M=({appName:u,loading:m,success:i,errorMessage:e,connectUri:r,onBack:s,onClose:c,onOpenFarcaster:o})=>t.jsx(_,x.isMobile||m?x.isIOS?{title:e?e.message:"Add a signer to Farcaster",subtitle:e?e.detail:`This will allow ${u} to add casts, likes, follows, and more on your behalf.`,icon:h,iconVariant:"loading",iconLoadingStatus:{success:i,fail:!!e},primaryCta:r&&o?{label:"Open Farcaster app",onClick:o}:void 0,onBack:s,onClose:c,watermark:!0}:{title:e?e.message:"Requesting signer from Farcaster",subtitle:e?e.detail:"This should only take a moment",icon:h,iconVariant:"loading",iconLoadingStatus:{success:i,fail:!!e},onBack:s,onClose:c,watermark:!0,children:r&&x.isMobile&&t.jsx(A,{children:t.jsx(q,{text:"Take me to Farcaster",url:r,color:S})})}:{title:"Add a signer to Farcaster",subtitle:`This will allow ${u} to add casts, likes, follows, and more on your behalf.`,onBack:s,onClose:c,watermark:!0,children:t.jsxs(R,{children:[t.jsx(z,{children:r?t.jsx(B,{url:r,size:275,squareLogoElement:h}):t.jsx(P,{children:t.jsx(E,{})})}),t.jsxs(L,{children:[t.jsx(N,{children:"Or copy this link and paste it into a phone browser to open the Farcaster app."}),r&&t.jsx(O,{text:r,itemName:"link",color:S})]})]})});let A=n.div`
  margin-top: 24px;
`,R=n.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
`,z=n.div`
  padding: 24px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 275px;
`,L=n.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
`,N=n.div`
  font-size: 0.875rem;
  text-align: center;
  color: var(--privy-color-foreground-2);
`,P=n.div`
  position: relative;
  width: 82px;
  height: 82px;
`;const te={component:()=>{let{lastScreen:u,navigateBack:m,data:i}=F(),e=T(),{requestFarcasterSignerStatus:r,closePrivyModal:s}=I(),[c,o]=d.useState(void 0),[j,v]=d.useState(!1),[b,y]=d.useState(!1),f=d.useRef([]),a=i==null?void 0:i.farcasterSigner;d.useEffect(()=>{let w=Date.now(),l=setInterval(async()=>{if(!(a!=null&&a.public_key))return clearInterval(l),void o({retryable:!0,message:"Connect failed",detail:"Something went wrong. Please try again."});a.status==="approved"&&(clearInterval(l),v(!1),y(!0),f.current.push(setTimeout(()=>s({shouldCallAuthOnSuccess:!1,isSuccess:!0}),k)));let p=await r(a==null?void 0:a.public_key),C=Date.now()-w;p.status==="approved"?(clearInterval(l),v(!1),y(!0),f.current.push(setTimeout(()=>s({shouldCallAuthOnSuccess:!1,isSuccess:!0}),k))):C>3e5?(clearInterval(l),o({retryable:!0,message:"Connect failed",detail:"The request timed out. Try again."})):p.status==="revoked"&&(clearInterval(l),o({retryable:!0,message:"Request rejected",detail:"The request was rejected. Please try again."}))},2e3);return()=>{clearInterval(l),f.current.forEach(p=>clearTimeout(p))}},[]);let g=(a==null?void 0:a.status)==="pending_approval"?a.signer_approval_url:void 0;return t.jsx(M,{appName:e.name,loading:j,success:b,errorMessage:c,connectUri:g,onBack:u?m:void 0,onClose:s,onOpenFarcaster:()=>{g&&(window.location.href=g)}})}};export{te as FarcasterSignerStatusScreen,M as FarcasterSignerStatusView,te as default};
