import{d4 as e,dy as n,dG as I,ff as L,d7 as N,d5 as A,d9 as b,da as g,ea as P,fg as S}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as m}from"./index-6mJiZeaw.js";import{a as M,c as v}from"./TodoList-CgrU7uwu-o94wl_BX.js";import{n as j}from"./ScreenLayout-BMEsmxmC-DRwMW8Lv.js";import{C as U}from"./circle-check-big-BSOM-yyF.js";import{F as C}from"./fingerprint-pattern-DyCnifoy.js";import{c as $}from"./createLucideIcon-CWcIInnG.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./x-C5vvIZmE.js";import"./check-udIDPn4r.js";import"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-Dq_xe9dz-CpsEonUS.js";/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],W=$("trash-2",z),B=({passkeys:i,name:c,isLoading:u,errorReason:f,success:o,expanded:a,onLinkPasskey:y,onUnlinkPasskey:t,onExpand:r,onBack:s,onClose:d})=>o?e.jsx(j,{title:"Passkeys updated",icon:U,iconVariant:"success",primaryCta:{label:"Done",onClick:d},onClose:d,watermark:!0}):a?e.jsx(j,{icon:C,title:"Your passkeys",onBack:s,onClose:d,watermark:!0,children:e.jsx(E,{passkeys:i,expanded:a,onUnlink:t,onExpand:r})}):e.jsxs(j,{icon:C,title:"Set up passkey verification",subtitle:"Verify with passkey",primaryCta:{label:"Add new passkey",onClick:y,loading:u},onClose:d,watermark:!0,helpText:f||void 0,children:[i.length===0?e.jsx(O,{}):e.jsx(T,{children:e.jsx(E,{passkeys:i,expanded:a,onUnlink:t,onExpand:r})}),c?e.jsxs(_,{children:[e.jsx(V,{children:"New Passkey Name"}),e.jsx(D,{children:c})]}):null]});let T=n.div`
  margin-bottom: 0.75rem;
`,_=n.div`
  margin-top: 0.25rem;
`,V=n.div`
  color: var(--privy-color-foreground-2);
  font-size: 0.75rem;
  font-weight: 500;
  line-height: 1rem;
  margin-bottom: 0.25rem;
`,D=n.div`
  color: var(--privy-color-foreground);
  font-size: 0.875rem;
  line-height: 1.25rem;
`,E=({passkeys:i,expanded:c,onUnlink:u,onExpand:f})=>{let[o,a]=m.useState([]),y=c?i.length:2;return e.jsxs("div",{children:[e.jsx(G,{children:"Your passkeys"}),e.jsxs(Y,{children:[i.slice(0,y).map(t=>{var s;return e.jsxs(H,{children:[e.jsxs("div",{children:[e.jsx(K,{children:(r=t,r.authenticatorName?r.createdWithBrowser?`${r.authenticatorName} on ${r.createdWithBrowser}`:r.authenticatorName:r.createdWithBrowser?r.createdWithOs?`${r.createdWithBrowser} on ${r.createdWithOs}`:`${r.createdWithBrowser}`:"Unknown device")}),e.jsxs(q,{children:["Last used:"," ",((s=t.latestVerifiedAt??t.firstVerifiedAt)==null?void 0:s.toLocaleString())??"N/A"]})]}),e.jsx(J,{disabled:o.includes(t.credentialId),onClick:()=>(async d=>{a(l=>l.concat([d])),await u(d),a(l=>l.filter(k=>k!==d))})(t.credentialId),children:o.includes(t.credentialId)?e.jsx(S,{}):e.jsx(W,{size:16})})]},t.credentialId);var r}),i.length>2&&!c&&e.jsx(R,{onClick:f,children:"View all"})]})]})},O=()=>e.jsxs(M,{style:{color:"var(--privy-color-foreground)"},children:[e.jsx(v,{children:"Verify with Touch ID, Face ID, PIN, or hardware key"}),e.jsx(v,{children:"Takes seconds to set up and use"}),e.jsx(v,{children:"Use your passkey to verify transactions and login to your account"})]});const me={component:()=>{var w;let{user:i}=I(),{unlink:c}=L(),{linkWithPasskey:u,closePrivyModal:f}=N(),{data:o}=A(),a=i==null?void 0:i.linkedAccounts.filter(p=>p.type==="passkey"),[y,t]=m.useState(!1),[r,s]=m.useState(""),[d,l]=m.useState(!1),[k,x]=m.useState(!1);return m.useEffect(()=>{a.length===0&&x(!1)},[a.length]),e.jsx(B,{passkeys:a,name:(w=o==null?void 0:o.passkeyAuthModalData)==null?void 0:w.name,isLoading:y,errorReason:r,success:d,expanded:k,onLinkPasskey:()=>{var p;t(!0),u({name:(p=o==null?void 0:o.passkeyAuthModalData)==null?void 0:p.name}).then(()=>l(!0)).catch(h=>{if(h instanceof b){if(h.privyErrorCode===g.CANNOT_LINK_MORE_OF_TYPE)return void s("Cannot link more passkeys to account.");if(h.privyErrorCode===g.PASSKEY_NOT_ALLOWED)return void s("Passkey request timed out or rejected by user.")}s("Unknown error occurred.")}).finally(()=>{t(!1)})},onUnlinkPasskey:async p=>(t(!0),await c({credentialId:p}).then(()=>l(!0)).catch(h=>{h instanceof b&&h.privyErrorCode===g.MISSING_MFA_CREDENTIALS?s("Cannot unlink a passkey enrolled in MFA"):s("Unknown error occurred.")}).finally(()=>{t(!1)})),onExpand:()=>x(!0),onBack:()=>x(!1),onClose:()=>f()})}},ue=n.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 180px;
  height: 90px;
  border-radius: 50%;
  svg + svg {
    margin-left: 12px;
  }
  > svg {
    z-index: 2;
    color: var(--privy-color-accent) !important;
    stroke: var(--privy-color-accent) !important;
    fill: var(--privy-color-accent) !important;
  }
`;let F=P`
  && {
    width: 100%;
    font-size: 0.875rem;
    line-height: 1rem;

    /* Tablet and Up */
    @media (min-width: 440px) {
      font-size: 14px;
    }

    display: flex;
    gap: 12px;
    justify-content: center;

    padding: 6px 8px;
    background-color: var(--privy-color-background);
    transition: background-color 200ms ease;
    color: var(--privy-color-accent) !important;

    :focus {
      outline: none;
      box-shadow: none;
    }
  }
`;const R=n.button`
  ${F}
`;let Y=n.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 0.8rem;
  padding: 0.5rem 0rem 0rem;
  flex-grow: 1;
  width: 100%;
`,G=n.div`
  line-height: 20px;
  height: 20px;
  font-size: 1em;
  font-weight: 450;
  display: flex;
  justify-content: flex-beginning;
  width: 100%;
`,K=n.div`
  font-size: 1em;
  line-height: 1.3em;
  font-weight: 500;
  color: var(--privy-color-foreground-2);
  padding: 0.2em 0;
`,q=n.div`
  font-size: 0.875rem;
  line-height: 1rem;
  color: #64668b;
  padding: 0.2em 0;
`,H=n.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1em;
  gap: 10px;
  font-size: 0.875rem;
  line-height: 1rem;
  text-align: left;
  border-radius: 8px;
  border: 1px solid #e2e3f0 !important;
  width: 100%;
  height: 5em;
`,Q=P`
  :focus,
  :hover,
  :active {
    outline: none;
  }
  display: flex;
  width: 2em;
  height: 2em;
  justify-content: center;
  align-items: center;
  svg {
    color: var(--privy-color-error);
  }
  svg:hover {
    color: var(--privy-color-foreground-3);
  }
`,J=n.button`
  ${Q}
`;export{ue as DoubleIconWrapper,R as LinkButton,me as LinkPasskeyScreen,B as LinkPasskeyView,me as default};
