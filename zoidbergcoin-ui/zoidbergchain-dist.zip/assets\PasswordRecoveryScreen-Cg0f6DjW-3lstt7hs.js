import{dG as T,d7 as _,d5 as I,d4 as e,eH as E,eI as F,e5 as U,dy as p,ea as W}from"./PrivyLoginIsland-CDPVUWBM.js";import{F as H}from"./ShieldCheckIcon-Co0xGMG8.js";import{r as a}from"./index-6mJiZeaw.js";import{m as N}from"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import{l as O}from"./Layouts-BlFm53ED-IewZfAqF.js";import{g as V,h as z,u as M,b as B,k as D}from"./shared-DA61dxhx-EL8LHHaz.js";import{w as s}from"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./index-Dq_xe9dz-CpsEonUS.js";const oe={component:()=>{let[o,m]=a.useState(!0),{authenticated:y,user:b}=T(),{walletProxy:i,closePrivyModal:v,createAnalyticsEvent:x,client:j}=_(),{navigate:k,data:A,onUserCloseViaDialogOrKeybindRef:$}=I(),[l,C]=a.useState(void 0),[f,d]=a.useState(""),[c,g]=a.useState(!1),{entropyId:u,entropyIdVerifier:S,onCompleteNavigateTo:w,onSuccess:h,onFailure:P}=A.recoverWallet,n=(r="User exited before their wallet could be recovered")=>{v({shouldCallAuthOnSuccess:!1}),P(typeof r=="string"?new U(r):r)};return $.current=n,a.useEffect(()=>{if(!y)return n("User must be authenticated and have a Privy wallet before it can be recovered")},[y]),e.jsxs(s,{children:[e.jsx(s.Header,{icon:H,title:"Enter your password",subtitle:"Please provision your account on this new device. To continue, enter your recovery password.",showClose:!0,onClose:n}),e.jsx(s.Body,{children:e.jsx(G,{children:e.jsxs("div",{children:[e.jsxs(V,{children:[e.jsx(z,{type:o?"password":"text",onChange:r=>(t=>{t&&C(t)})(r.target.value),disabled:c,style:{paddingRight:"2.3rem"}}),e.jsx(M,{style:{right:"0.75rem"},children:o?e.jsx(B,{onClick:()=>m(!1)}):e.jsx(D,{onClick:()=>m(!0)})})]}),!!f&&e.jsx(K,{children:f})]})})}),e.jsxs(s.Footer,{children:[e.jsx(s.HelpText,{children:e.jsxs(O,{children:[e.jsx("h4",{children:"Why is this necessary?"}),e.jsx("p",{children:"You previously set a password for this wallet. This helps ensure only you can access it"})]})}),e.jsx(s.Actions,{children:e.jsx(Y,{loading:c||!i,disabled:!l,onClick:async()=>{g(!0);let r=await j.getAccessToken(),t=E(b,u);if(!r||!t||l===null)return n("User must be authenticated and have a Privy wallet before it can be recovered");try{x({eventName:"embedded_wallet_recovery_started",payload:{walletAddress:t.address}}),await(i==null?void 0:i.recover({accessToken:r,entropyId:u,entropyIdVerifier:S,recoveryPassword:l})),d(""),w?k(w):v({shouldCallAuthOnSuccess:!1}),h==null||h(t),x({eventName:"embedded_wallet_recovery_completed",payload:{walletAddress:t.address}})}catch(R){F(R)?d("Invalid recovery password, please try again."):d("An error has occurred, please try again.")}finally{g(!1)}},$hideAnimations:!u&&c,children:"Recover your account"})}),e.jsx(s.Watermark,{})]})]})}};let G=p.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,K=p.div`
  line-height: 20px;
  height: 20px;
  font-size: 13px;
  color: var(--privy-color-error);
  text-align: left;
  margin-top: 0.5rem;
`,Y=p(N)`
  ${({$hideAnimations:o})=>o&&W`
      && {
        // Remove animations because the recoverWallet task on the iframe partially
        // blocks the renderer, so the animation stutters and doesn't look good
        transition: none;
      }
    `}
`;export{oe as PasswordRecoveryScreen,oe as default};
