import{d4 as a,dG as A,d7 as M,d5 as N,fp as O,dM as E,eS as b,eT as C,dC as q,dy as p,dQ as z,fq as I,fr as P}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as o}from"./index-6mJiZeaw.js";import{h as F}from"./CopyToClipboard-DSTf_eKU-B6BaLONm.js";import{a as V}from"./Layouts-BlFm53ED-IewZfAqF.js";import{a as H,i as J}from"./JsonTree-aPaJmPx7-DQb1CeWV.js";import{n as Q}from"./ScreenLayout-BMEsmxmC-DRwMW8Lv.js";import{c as G}from"./createLucideIcon-CWcIInnG.js";import"./index-BH_ioaGe.js";import"./index-Dh4ylHKt.js";import"./index-XNTK91Jg.js";import"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import"./Screen-BSVfJbdY-yqxp8pcY.js";import"./index-Dq_xe9dz-CpsEonUS.js";/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",key:"ohrbg2"}]],W=G("square-pen",K),B=p.img`
  && {
    height: ${e=>e.size==="sm"?"65px":"140px"};
    width: ${e=>e.size==="sm"?"65px":"140px"};
    border-radius: 16px;
    margin-bottom: 12px;
  }
`;let X=e=>{if(!z(e))return e;try{let s=I(e);return s.includes("�")?e:s}catch{return e}},Y=e=>{try{let s=P.decode(e),n=new TextDecoder().decode(s);return n.includes("�")?e:n}catch{return e}},Z=e=>{let{types:s,primaryType:n,...l}=e.typedData;return a.jsxs(a.Fragment,{children:[a.jsx(te,{data:l}),a.jsx(F,{text:(r=e.typedData,JSON.stringify(r,null,2)),itemName:"full payload to clipboard"})," "]});var r};const k=({method:e,messageData:s,copy:n,iconUrl:l,isLoading:r,success:g,walletProxyIsLoading:m,errorMessage:x,isCancellable:c,onSign:d,onCancel:f,onClose:u})=>a.jsx(Q,{title:n.title,subtitle:n.description,showClose:!0,onClose:u,icon:W,iconVariant:"subtle",helpText:x?a.jsx(ee,{children:x}):void 0,primaryCta:{label:n.buttonText,onClick:d,disabled:r||g||m,loading:r},secondaryCta:c?{label:"Not now",onClick:f,disabled:r||g||m}:void 0,watermark:!0,children:a.jsxs(V,{children:[l?a.jsx(B,{style:{alignSelf:"center"},size:"sm",src:l,alt:"app image"}):null,a.jsxs($,{children:[e==="personal_sign"&&a.jsx(w,{children:X(s)}),e==="eth_signTypedData_v4"&&a.jsx(Z,{typedData:s}),e==="solana_signMessage"&&a.jsx(w,{children:Y(s)})]})]})}),xe={component:()=>{let{authenticated:e}=A(),{initializeWalletProxy:s,closePrivyModal:n}=M(),{navigate:l,data:r,onUserCloseViaDialogOrKeybindRef:g}=N(),[m,x]=o.useState(!0),[c,d]=o.useState(""),[f,u]=o.useState(),[y,T]=o.useState(null),[_,S]=o.useState(!1);o.useEffect(()=>{e||l("LandingScreen")},[e]),o.useEffect(()=>{s(O).then(i=>{x(!1),i||(d("An error has occurred, please try again."),u(new E(new b(c,C.E32603_DEFAULT_INTERNAL_ERROR.eipCode))))})},[]);let{method:R,data:j,confirmAndSign:D,onSuccess:L,onFailure:U,uiOptions:t}=r.signMessage,v={title:(t==null?void 0:t.title)||"Sign message",description:(t==null?void 0:t.description)||"Signing this message will not cost you any fees.",buttonText:(t==null?void 0:t.buttonText)||"Sign and continue"},h=i=>{i?L(i):U(f||new E(new b("The user rejected the request.",C.E4001_USER_REJECTED_REQUEST.eipCode))),n({shouldCallAuthOnSuccess:!1}),setTimeout(()=>{T(null),d(""),u(void 0)},200)};return g.current=()=>{h(y)},a.jsx(k,{method:R,messageData:j,copy:v,iconUrl:t!=null&&t.iconUrl&&typeof t.iconUrl=="string"?t.iconUrl:void 0,isLoading:_,success:y!==null,walletProxyIsLoading:m,errorMessage:c,isCancellable:t==null?void 0:t.isCancellable,onSign:async()=>{S(!0),d("");try{let i=await D();T(i),S(!1),setTimeout(()=>{h(i)},q)}catch(i){console.error(i),d("An error has occurred, please try again."),u(new E(new b(c,C.E32603_DEFAULT_INTERNAL_ERROR.eipCode))),S(!1)}},onCancel:()=>h(null),onClose:()=>h(y)})}};let $=p.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 16px;
`,ee=p.p`
  && {
    margin: 0;
    width: 100%;
    text-align: center;
    color: var(--privy-color-error-dark);
    font-size: 14px;
    line-height: 22px;
  }
`,te=p(H)`
  margin-top: 0;
`,w=p(J)`
  margin-top: 0;
`;export{xe as SignRequestScreen,k as SignRequestView,xe as default};
