import{d7 as Ve,d4 as e,d6 as xe,eC as ne,eo as he,gG as ze,dy as h,gH as We}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as g}from"./index-6mJiZeaw.js";import{T as X,g as Ue,m as Z,u as je,V as qe}from"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import{t as V,s,e as n,n as i,a as Je}from"./Value-Dsq_d-nN-CQnRGERH.js";import{e as H}from"./ErrorMessage-D8VaAP5m-Yy7PPpsf.js";import{r as O}from"./LabelXs-oqZNqbm_-CyO8h7Kr.js";import{r as me}from"./Subtitle-CV-2yKE4-BPrCdfBE.js";import{e as ue}from"./Title-BnzYV3Is-CK5vKK5F.js";import{d as c}from"./Address-BPv73sF9-ayAxkKXK.js";import{j as Qe}from"./WalletInfoCard-DQ7y6bai-tzzQlF4I.js";import{n as pe}from"./LoadingSkeleton-CeUcJdAQ-CDhyoiGZ.js";import{d as Xe}from"./shared-FM0rljBt-Dl1dglJ0.js";import{o as Ze,F as Ge}from"./Checkbox-BhNoOKjX-DWwVHeEx.js";import{i as Ke}from"./ErrorBanner-BcpGRt0h-Cum9Px6Q.js";import{t as Ye}from"./WarningBanner-ZZqCEtZK-C9ukCDb_.js";import{F as _e}from"./ExclamationCircleIcon-BhQG-EMt.js";import{F as fe}from"./ChevronDownIcon-VVK3yiEw.js";function Pe({title:l,titleId:a,...o},m){return g.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:m,"aria-labelledby":a},o),l?g.createElement("title",{id:a},l):null,g.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"}))}const $e=g.forwardRef(Pe);function er({title:l,titleId:a,...o},m){return g.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:m,"aria-labelledby":a},o),l?g.createElement("title",{id:a},l):null,g.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z"}))}const ge=g.forwardRef(er);function rr({title:l,titleId:a,...o},m){return g.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:m,"aria-labelledby":a},o),l?g.createElement("title",{id:a},l):null,g.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.057 1.123-.08M15.75 18H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08M15.75 18.75v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5A3.375 3.375 0 0 0 6.375 7.5H5.25m11.9-3.664A2.251 2.251 0 0 0 15 2.25h-1.5a2.251 2.251 0 0 0-2.15 1.586m5.8 0c.065.21.1.433.1.664v.75h-6V4.5c0-.231.035-.454.1-.664M6.75 7.5H4.875c-.621 0-1.125.504-1.125 1.125v12c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V16.5a9 9 0 0 0-9-9Z"}))}const sr=g.forwardRef(rr),ye=h(n)`
  cursor: pointer;
  display: inline-flex;
  gap: 8px;
  align-items: center;
  color: var(--privy-color-accent);
  svg {
    fill: var(--privy-color-accent);
  }
`;var ie=({iconUrl:l,value:a,symbol:o,usdValue:m,nftName:E,nftCount:p,decimals:t,$isLoading:y})=>{if(y)return e.jsx(te,{$isLoading:y});let k=a&&m&&t?function(b,I,S){let v=parseFloat(b),x=parseFloat(S);if(v===0||x===0||Number.isNaN(v)||Number.isNaN(x))return b;let f=Math.ceil(-Math.log10(.01/(x/v))),d=Math.pow(10,f=Math.max(f=Math.min(f,I),1)),T=+(Math.floor(v*d)/d).toFixed(f).replace(/\.?0+$/,"");return Intl.NumberFormat(void 0,{maximumFractionDigits:I}).format(T)}(a,t,m):a;return e.jsxs("div",{children:[e.jsxs(te,{$isLoading:y,children:[l&&e.jsx(ir,{src:l,alt:"Token icon"}),p&&p>1?p+"x":void 0," ",E,k," ",o]}),m&&e.jsxs(nr,{$isLoading:y,children:["$",m]})]})};let te=h.span`
  color: var(--privy-color-foreground);
  font-size: 0.875rem;
  font-weight: 500;
  line-height: 1.375rem;
  word-break: break-all;
  text-align: right;
  display: flex;
  justify-content: flex-end;

  /**
   * @NOTE This is a code smell anti-pattern for styling components.
   * We are mixing JSX definitions with styled-components CSS definitions.
   * This is not ideal and should be refactored in the future to separate concerns.
   * This is also hard to read, as it makes it difficult to understand the structure
   * of the component and its styles by viewing the JSX.
   */

  ${pe}
`;const nr=h.span`
  color: var(--privy-color-foreground-2);
  font-size: 12px;
  font-weight: 400;
  line-height: 18px;
  word-break: break-all;
  text-align: right;
  display: flex;
  justify-content: flex-end;

  ${pe}
`;let ir=h.img`
  height: 14px;
  width: 14px;
  margin-right: 4px;
  object-fit: contain;
`;const tr=l=>{var y,k,b,I,S,v,x,f;let{chain:a,transactionDetails:o,isTokenContractInfoLoading:m,symbol:E}=l,{action:p,functionName:t}=o;return e.jsx(Xe,{children:e.jsxs(V,{children:[p!=="transaction"&&e.jsxs(s,{children:[e.jsx(n,{children:"Action"}),e.jsx(i,{children:t})]}),t==="mint"&&"args"in o&&o.args.filter(d=>d).map((d,T)=>{var u,C;return e.jsxs(s,{children:[e.jsx(n,{children:`Param ${T}`}),e.jsx(i,{children:typeof d=="string"&&We(d)?e.jsx(c,{address:d,url:(C=(u=a==null?void 0:a.blockExplorers)==null?void 0:u.default)==null?void 0:C.url,showCopyIcon:!1}):d==null?void 0:d.toString()})]},T)}),t==="setApprovalForAll"&&o.operator&&e.jsxs(s,{children:[e.jsx(n,{children:"Operator"}),e.jsx(i,{children:e.jsx(c,{address:o.operator,url:(k=(y=a==null?void 0:a.blockExplorers)==null?void 0:y.default)==null?void 0:k.url,showCopyIcon:!1})})]}),t==="setApprovalForAll"&&o.approved!==void 0&&e.jsxs(s,{children:[e.jsx(n,{children:"Set approval to"}),e.jsx(i,{children:o.approved?"true":"false"})]}),t==="transfer"||t==="transferWithMemo"||t==="transferFrom"||t==="safeTransferFrom"||t==="approve"?e.jsxs(e.Fragment,{children:["formattedAmount"in o&&o.formattedAmount&&e.jsxs(s,{children:[e.jsx(n,{children:"Amount"}),e.jsxs(i,{$isLoading:m,children:[o.formattedAmount," ",E]})]}),"tokenId"in o&&o.tokenId&&e.jsxs(s,{children:[e.jsx(n,{children:"Token ID"}),e.jsx(i,{children:o.tokenId.toString()})]})]}):null,t==="safeBatchTransferFrom"&&e.jsxs(e.Fragment,{children:["amounts"in o&&o.amounts&&e.jsxs(s,{children:[e.jsx(n,{children:"Amounts"}),e.jsx(i,{children:o.amounts.join(", ")})]}),"tokenIds"in o&&o.tokenIds&&e.jsxs(s,{children:[e.jsx(n,{children:"Token IDs"}),e.jsx(i,{children:o.tokenIds.join(", ")})]})]}),t==="approve"&&o.spender&&e.jsxs(s,{children:[e.jsx(n,{children:"Spender"}),e.jsx(i,{children:e.jsx(c,{address:o.spender,url:(I=(b=a==null?void 0:a.blockExplorers)==null?void 0:b.default)==null?void 0:I.url,showCopyIcon:!1})})]}),(t==="transferFrom"||t==="safeTransferFrom"||t==="safeBatchTransferFrom")&&o.transferFrom&&e.jsxs(s,{children:[e.jsx(n,{children:"Transferring from"}),e.jsx(i,{children:e.jsx(c,{address:o.transferFrom,url:(v=(S=a==null?void 0:a.blockExplorers)==null?void 0:S.default)==null?void 0:v.url,showCopyIcon:!1})})]}),(t==="transferFrom"||t==="safeTransferFrom"||t==="safeBatchTransferFrom")&&o.transferTo&&e.jsxs(s,{children:[e.jsx(n,{children:"Transferring to"}),e.jsx(i,{children:e.jsx(c,{address:o.transferTo,url:(f=(x=a==null?void 0:a.blockExplorers)==null?void 0:x.default)==null?void 0:f.url,showCopyIcon:!1})})]})]})})},or=({variant:l,setPreventMaliciousTransaction:a,colorScheme:o="light",preventMaliciousTransaction:m})=>l==="warn"?e.jsx(oe,{children:e.jsxs(Ye,{theme:o,children:[e.jsx("span",{style:{fontWeight:"500"},children:"Warning: Suspicious transaction"}),e.jsx("br",{}),"This has been flagged as a potentially deceptive request. Approving could put your assets or funds at risk."]})}):l==="error"?e.jsx(e.Fragment,{children:e.jsxs(oe,{children:[e.jsx(Ke,{theme:o,children:e.jsxs("div",{children:[e.jsx("strong",{children:"This is a malicious transaction"}),e.jsx("br",{}),"This transaction transfers tokens to a known malicious address. Proceeding may result in the loss of valuable assets."]})}),e.jsxs(ar,{children:[e.jsx(Ze,{color:"var(--privy-color-error)",checked:!m,readOnly:!0,onClick:()=>a(!m)}),e.jsx("span",{children:"I understand and want to proceed anyways."})]})]})}):null;let oe=h.div`
  margin-top: 1.5rem;
`,ar=h.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-top: 0.75rem;
`;const lr=({transactionIndex:l,maxIndex:a})=>typeof l!="number"||a===0?"":` (${l+1} / ${a+1})`,Hr=({img:l,submitError:a,prepareError:o,onClose:m,action:E,title:p,subtitle:t,to:y,tokenAddress:k,network:b,missingFunds:I,fee:S,from:v,cta:x,disabled:f,chain:d,isSubmitting:T,isPreparing:u,isTokenPriceLoading:C,isTokenContractInfoLoading:A,isSponsored:L,symbol:z,balance:R,onClick:N,transactionDetails:F,transactionIndex:B,maxIndex:W,onBack:r,chainName:w,validation:U,hasScanDetails:G,setIsScanDetailsOpen:Ie,preventMaliciousTransaction:Se,setPreventMaliciousTransaction:Ce,tokensSent:K,tokensReceived:q,isScanning:Fe,isCancellable:Me,functionName:Ee})=>{var Y,_,P,$,ee,re;let{showTransactionDetails:J,setShowTransactionDetails:Oe,hasMoreDetails:Ae,isErc20Ish:Ne}=(j=>{let[D,Re]=g.useState(!1),Q=!0,se=!1;return(!j||j.isErc20Ish||j.action==="transaction")&&(Q=!1),Q&&(se=Object.entries(j||{}).some(([Be,He])=>He&&!["action","isErc20Ish","isNFTIsh"].includes(Be))),{showTransactionDetails:D,setShowTransactionDetails:Re,hasMoreDetails:Q&&se,isErc20Ish:j==null?void 0:j.isErc20Ish}})(F),Le=xe(),De=Ne&&A||u||C||Fe;return e.jsxs(e.Fragment,{children:[e.jsx(X,{onClose:m,backFn:r}),l&&e.jsx(be,{children:l}),e.jsxs(ue,{style:{marginTop:l?"1.5rem":0},children:[p,e.jsx(lr,{maxIndex:W,transactionIndex:B})]}),e.jsx(me,{children:t}),e.jsxs(V,{style:{marginTop:"2rem"},children:[(!!K[0]||De)&&e.jsxs(s,{children:[q.length>0?e.jsx(n,{children:"Send"}):e.jsx(n,{children:E==="approve"?"Approval amount":"Amount"}),e.jsx("div",{className:"flex flex-col",children:K.map((j,D)=>e.jsx(ie,{iconUrl:j.iconUrl,value:Ee==="setApprovalForAll"?"All":j.value,usdValue:j.usdValue,symbol:j.symbol,nftName:j.nftName,nftCount:j.nftCount,decimals:j.decimals},D))})]}),q.length>0&&e.jsxs(s,{children:[e.jsx(n,{children:"Receive"}),e.jsx("div",{className:"flex flex-col",children:q.map((j,D)=>e.jsx(ie,{iconUrl:j.iconUrl,value:j.value,usdValue:j.usdValue,symbol:j.symbol,nftName:j.nftName,nftCount:j.nftCount,decimals:j.decimals},D))})]}),F&&"spender"in F&&(F!=null&&F.spender)?e.jsxs(s,{children:[e.jsx(n,{children:"Spender"}),e.jsx(i,{children:e.jsx(c,{address:F.spender,url:(_=(Y=d==null?void 0:d.blockExplorers)==null?void 0:Y.default)==null?void 0:_.url})})]}):null,y&&e.jsxs(s,{children:[e.jsx(n,{children:"To"}),e.jsx(i,{children:e.jsx(c,{address:y,url:($=(P=d==null?void 0:d.blockExplorers)==null?void 0:P.default)==null?void 0:$.url,showCopyIcon:!0})})]}),k&&e.jsxs(s,{children:[e.jsx(n,{children:"Token address"}),e.jsx(i,{children:e.jsx(c,{address:k,url:(re=(ee=d==null?void 0:d.blockExplorers)==null?void 0:ee.default)==null?void 0:re.url})})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Network"}),e.jsx(i,{children:b})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Estimated fee"}),e.jsx(i,{$isLoading:u||C||L===void 0,children:L?e.jsxs(ve,{children:[e.jsxs(Te,{children:["Sponsored by ",Le.name]}),e.jsx(ge,{height:16,width:16})]}):S})]}),Ae&&!G&&e.jsxs(e.Fragment,{children:[e.jsx(s,{className:"cursor-pointer",onClick:()=>Oe(!J),children:e.jsxs(Je,{className:"flex items-center gap-x-1",children:["Details"," ",e.jsx(fe,{style:{width:"0.75rem",marginLeft:"0.25rem",transform:J?"rotate(180deg)":void 0}})]})}),J&&F&&e.jsx(tr,{action:E,chain:d,transactionDetails:F,isTokenContractInfoLoading:A,symbol:z})]}),G&&e.jsx(s,{children:e.jsxs(ye,{onClick:()=>Ie(!0),children:[e.jsx("span",{className:"text-color-primary",children:"Details"}),e.jsx($e,{height:"14px",width:"14px",strokeWidth:"2"})]})})]}),e.jsx(he,{}),a?e.jsx(H,{style:{marginTop:"2rem"},children:a.message}):o&&B===0?e.jsx(H,{style:{marginTop:"2rem"},children:o.shortMessage??we}):null,e.jsx(or,{variant:U,preventMaliciousTransaction:Se,setPreventMaliciousTransaction:Ce}),e.jsx(ke,{$useSmallMargins:!(!o&&!a&&U!=="warn"&&U!=="error"),address:v,balance:R,errMsg:u||o||a||!I?void 0:`Add funds on ${(d==null?void 0:d.name)??w} to complete transaction.`}),e.jsx(Z,{style:{marginTop:"1rem"},loading:T,disabled:f||u,onClick:N,children:x}),Me&&e.jsx(qe,{style:{marginTop:"1rem"},onClick:m,isSubmitting:!1,children:"Not now"}),e.jsx(je,{})]})},Vr=({img:l,title:a,subtitle:o,cta:m,instructions:E,network:p,blockExplorerUrl:t,isMissingFunds:y,submitError:k,parseError:b,total:I,swap:S,transactingWalletAddress:v,fee:x,balance:f,disabled:d,isSubmitting:T,isPreparing:u,isTokenPriceLoading:C,onClick:A,onClose:L,onBack:z,isSponsored:R})=>{let N=u||C,[F,B]=g.useState(!1),W=xe();return e.jsxs(e.Fragment,{children:[e.jsx(X,{onClose:L,backFn:z}),l&&e.jsx(be,{children:l}),e.jsx(ue,{style:{marginTop:l?"1.5rem":0},children:a}),e.jsx(me,{children:o}),e.jsxs(V,{style:{marginTop:"2rem",marginBottom:".5rem"},children:[(I||N)&&e.jsxs(s,{children:[e.jsx(n,{children:"Amount"}),e.jsx(i,{$isLoading:N,children:I})]}),S&&e.jsxs(s,{children:[e.jsx(n,{children:"Swap"}),e.jsx(i,{children:S})]}),p&&e.jsxs(s,{children:[e.jsx(n,{children:"Network"}),e.jsx(i,{children:p})]}),(x||N||R!==void 0)&&e.jsxs(s,{children:[e.jsx(n,{children:"Estimated fee"}),e.jsx(i,{$isLoading:N,children:R&&!N?e.jsxs(ve,{children:[e.jsxs(Te,{children:["Sponsored by ",W.name]}),e.jsx(ge,{height:16,width:16})]}):x})]})]}),e.jsx(s,{children:e.jsxs(ye,{onClick:()=>B(r=>!r),children:[e.jsx("span",{children:"Advanced"}),e.jsx(fe,{height:"16px",width:"16px",strokeWidth:"2",style:{transition:"all 300ms",transform:F?"rotate(180deg)":void 0}})]})}),F&&e.jsx(e.Fragment,{children:E.map((r,w)=>r.type==="sol-transfer"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Transfer ",r.withSeed?"with seed":""]})}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount"}),e.jsxs(i,{children:[ne({amount:r.value,decimals:r.token.decimals})," ",r.token.symbol]})]}),!!r.toAccount&&e.jsxs(s,{children:[e.jsx(n,{children:"Destination"}),e.jsx(i,{children:e.jsx(c,{address:r.toAccount,url:t})})]})]},w):r.type==="spl-transfer"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Transfer ",r.token.symbol]})}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount"}),e.jsx(i,{children:r.value.toString()})]}),!!r.fromAta&&e.jsxs(s,{children:[e.jsx(n,{children:"Source"}),e.jsx(i,{children:e.jsx(c,{address:r.fromAta,url:t})})]}),!!r.toAta&&e.jsxs(s,{children:[e.jsx(n,{children:"Destination"}),e.jsx(i,{children:e.jsx(c,{address:r.toAta,url:t})})]}),!!r.token.address&&e.jsxs(s,{children:[e.jsx(n,{children:"Token"}),e.jsx(i,{children:e.jsx(c,{address:r.token.address,url:t})})]})]},w):r.type==="ata-creation"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsx(O,{children:"Create token account"})}),e.jsxs(s,{children:[e.jsx(n,{children:"Program ID"}),e.jsx(i,{children:e.jsx(c,{address:r.program,url:t})})]}),!!r.owner&&e.jsxs(s,{children:[e.jsx(n,{children:"Owner"}),e.jsx(i,{children:e.jsx(c,{address:r.owner,url:t})})]})]},w):r.type==="create-account"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Create account ",r.withSeed?"with seed":""]})}),!!r.account&&e.jsxs(s,{children:[e.jsx(n,{children:"Account"}),e.jsx(i,{children:e.jsx(c,{address:r.account,url:t})})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount"}),e.jsxs(i,{children:[ne({amount:r.value,decimals:9})," SOL"]})]})]},w):r.type==="spl-init-account"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsx(O,{children:"Initialize token account"})}),!!r.account&&e.jsxs(s,{children:[e.jsx(n,{children:"Account"}),e.jsx(i,{children:e.jsx(c,{address:r.account,url:t})})]}),!!r.mint&&e.jsxs(s,{children:[e.jsx(n,{children:"Mint"}),e.jsx(i,{children:e.jsx(c,{address:r.mint,url:t})})]}),!!r.owner&&e.jsxs(s,{children:[e.jsx(n,{children:"Owner"}),e.jsx(i,{children:e.jsx(c,{address:r.owner,url:t})})]})]},w):r.type==="spl-close-account"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsx(O,{children:"Close token account"})}),!!r.source&&e.jsxs(s,{children:[e.jsx(n,{children:"Source"}),e.jsx(i,{children:e.jsx(c,{address:r.source,url:t})})]}),!!r.destination&&e.jsxs(s,{children:[e.jsx(n,{children:"Destination"}),e.jsx(i,{children:e.jsx(c,{address:r.destination,url:t})})]}),!!r.owner&&e.jsxs(s,{children:[e.jsx(n,{children:"Owner"}),e.jsx(i,{children:e.jsx(c,{address:r.owner,url:t})})]})]},w):r.type==="spl-sync-native"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsx(O,{children:"Sync native"})}),e.jsxs(s,{children:[e.jsx(n,{children:"Program ID"}),e.jsx(i,{children:e.jsx(c,{address:r.program,url:t})})]})]},w):r.type==="raydium-swap-base-input"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Raydium swap"," ",r.tokenIn&&r.tokenOut?`${r.tokenIn.symbol} → ${r.tokenOut.symbol}`:""]})}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount in"}),e.jsx(i,{children:r.amountIn.toString()})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Minimum amount out"}),e.jsx(i,{children:r.minimumAmountOut.toString()})]}),r.mintIn&&e.jsxs(s,{children:[e.jsx(n,{children:"Token in"}),e.jsx(i,{children:e.jsx(c,{address:r.mintIn,url:t})})]}),r.mintOut&&e.jsxs(s,{children:[e.jsx(n,{children:"Token out"}),e.jsx(i,{children:e.jsx(c,{address:r.mintOut,url:t})})]})]},w):r.type==="raydium-swap-base-output"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Raydium swap"," ",r.tokenIn&&r.tokenOut?`${r.tokenIn.symbol} → ${r.tokenOut.symbol}`:""]})}),e.jsxs(s,{children:[e.jsx(n,{children:"Max amount in"}),e.jsx(i,{children:r.maxAmountIn.toString()})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount out"}),e.jsx(i,{children:r.amountOut.toString()})]}),r.mintIn&&e.jsxs(s,{children:[e.jsx(n,{children:"Token in"}),e.jsx(i,{children:e.jsx(c,{address:r.mintIn,url:t})})]}),r.mintOut&&e.jsxs(s,{children:[e.jsx(n,{children:"Token out"}),e.jsx(i,{children:e.jsx(c,{address:r.mintOut,url:t})})]})]},w):r.type==="jupiter-swap-shared-accounts-route"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Jupiter swap"," ",r.tokenIn&&r.tokenOut?`${r.tokenIn.symbol} → ${r.tokenOut.symbol}`:""]})}),e.jsxs(s,{children:[e.jsx(n,{children:"In amount"}),e.jsx(i,{children:r.inAmount.toString()})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Quoted out amount"}),e.jsx(i,{children:r.quotedOutAmount.toString()})]}),r.mintIn&&e.jsxs(s,{children:[e.jsx(n,{children:"Token in"}),e.jsx(i,{children:e.jsx(c,{address:r.mintIn,url:t})})]}),r.mintOut&&e.jsxs(s,{children:[e.jsx(n,{children:"Token out"}),e.jsx(i,{children:e.jsx(c,{address:r.mintOut,url:t})})]})]},w):r.type==="jupiter-swap-exact-out-route"?e.jsxs(M,{children:[e.jsx(s,{children:e.jsxs(O,{children:["Jupiter swap"," ",r.tokenIn&&r.tokenOut?`${r.tokenIn.symbol} → ${r.tokenOut.symbol}`:""]})}),e.jsxs(s,{children:[e.jsx(n,{children:"Quoted in amount"}),e.jsx(i,{children:r.quotedInAmount.toString()})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Amount out"}),e.jsx(i,{children:r.outAmount.toString()})]}),r.mintIn&&e.jsxs(s,{children:[e.jsx(n,{children:"Token in"}),e.jsx(i,{children:e.jsx(c,{address:r.mintIn,url:t})})]}),r.mintOut&&e.jsxs(s,{children:[e.jsx(n,{children:"Token out"}),e.jsx(i,{children:e.jsx(c,{address:r.mintOut,url:t})})]})]},w):e.jsxs(M,{children:[e.jsxs(s,{children:[e.jsx(n,{children:"Program ID"}),e.jsx(i,{children:e.jsx(c,{address:r.program,url:t})})]}),e.jsxs(s,{children:[e.jsx(n,{children:"Data"}),e.jsx(i,{children:r.discriminator})]})]},w))}),e.jsx(he,{}),k?e.jsx(H,{style:{marginTop:"2rem"},children:k.message}):b?e.jsx(H,{style:{marginTop:"2rem"},children:we}):null,e.jsx(ke,{$useSmallMargins:!(!b&&!k),title:"",address:v,balance:f,errMsg:u||b||k||!y?void 0:"Add funds on Solana to complete transaction."}),e.jsx(Z,{style:{marginTop:"1rem"},loading:T,disabled:d||u,onClick:A,children:m}),e.jsx(je,{})]})};let ke=h(Qe)`
  ${l=>l.$useSmallMargins?"margin-top: 0.5rem;":"margin-top: 2rem;"}
`,M=h(V)`
  margin-top: 0.5rem;
  border: 1px solid var(--privy-color-foreground-4);
  border-radius: var(--privy-border-radius-sm);
  padding: 0.5rem;
`,we="There was an error preparing your transaction. Your transaction request will likely fail.",be=h.div`
  display: flex;
  width: 100%;
  justify-content: center;
  max-height: 40px;

  > img {
    object-fit: contain;
    border-radius: var(--privy-border-radius-sm);
  }
`,ve=h.span`
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
`,Te=h.span`
  font-size: 14px;
  font-weight: 500;
  color: var(--privy-color-foreground);
`,ae=l=>(l==null?void 0:l.code)===ze.COMPLIANCE_BLOCKED,dr=()=>e.jsxs(jr,{children:[e.jsx(ur,{}),e.jsx(mr,{})]});const zr=({transactionError:l,chainId:a,onClose:o,onRetry:m,chainType:E,transactionHash:p})=>{let{chains:t}=Ve(),[y,k]=g.useState(!1),{errorCode:b,errorMessage:I}=((x,f)=>{if(f==="ethereum")return ae(x)?{errorCode:"Transaction blocked",errorMessage:x.message}:{errorCode:x.details??x.message,errorMessage:x.shortMessage};let d=x.txSignature,T=(x==null?void 0:x.transactionMessage)||"Something went wrong.";if(Array.isArray(x.logs)){let u=x.logs.find(C=>/insufficient (lamports|funds)/gi.test(C));u&&(T=u)}return{transactionHash:d,errorMessage:T}})(l,E),S=ae(l),v=(({chains:x,chainId:f,chainType:d,transactionHash:T})=>{var u,C;return d==="ethereum"?((C=(u=x.find(A=>A.id===f))==null?void 0:u.blockExplorers)==null?void 0:C.default.url)??"https://etherscan.io":function(A,L){return`https://explorer.solana.com/tx/${A}?chain=${L}`}(T||"",f)})({chains:t,chainId:a,chainType:E,transactionHash:p});return e.jsxs(e.Fragment,{children:[e.jsx(X,{onClose:o}),e.jsxs(cr,{children:[e.jsx(dr,{}),e.jsx(xr,{children:b}),e.jsx(hr,{children:S?"This transaction cannot be completed.":"Please try again."}),e.jsxs(de,{children:[e.jsx(le,{children:"Error message"}),e.jsx(ce,{$clickable:!1,children:I})]}),p&&e.jsxs(de,{children:[e.jsx(le,{children:"Transaction hash"}),e.jsxs(fr,{children:["Copy this hash to view details about the transaction on a"," ",e.jsx("u",{children:e.jsx("a",{href:v,children:"block explorer"})}),"."]}),e.jsxs(ce,{$clickable:!0,onClick:async()=>{await navigator.clipboard.writeText(p),k(!0)},children:[p,e.jsx(kr,{clicked:y})]})]}),!S&&e.jsx(pr,{onClick:()=>m({resetNonce:!!p}),children:"Retry transaction"})]}),e.jsx(Ue,{})]})};let cr=h.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,xr=h.span`
  color: var(--privy-color-foreground);
  text-align: center;
  font-size: 1.125rem;
  font-weight: 500;
  line-height: 1.25rem; /* 111.111% */
  text-align: center;
  margin: 10px;
`,hr=h.span`
  margin-top: 4px;
  margin-bottom: 10px;
  color: var(--privy-color-foreground-3);
  text-align: center;

  font-size: 0.875rem;
  font-style: normal;
  font-weight: 400;
  line-height: 20px; /* 142.857% */
  letter-spacing: -0.008px;
`,jr=h.div`
  position: relative;
  width: 60px;
  height: 60px;
  margin: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
`,mr=h(_e)`
  position: absolute;
  width: 35px;
  height: 35px;
  color: var(--privy-color-error);
`,ur=h.div`
  position: absolute;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background-color: var(--privy-color-error);
  opacity: 0.1;
`,pr=h(Z)`
  && {
    margin-top: 24px;
  }
  transition:
    color 350ms ease,
    background-color 350ms ease;
`,le=h.span`
  width: 100%;
  text-align: left;
  font-size: 0.825rem;
  color: var(--privy-color-foreground);
  padding: 4px;
`,de=h.div`
  width: 100%;
  margin: 5px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`,fr=h.text`
  position: relative;
  width: 100%;
  padding: 5px;
  font-size: 0.8rem;
  color: var(--privy-color-foreground-3);
  text-align: left;
  word-wrap: break-word;
`,ce=h.span`
  position: relative;
  width: 100%;
  background-color: var(--privy-color-background-2);
  padding: 8px 12px;
  border-radius: 10px;
  margin-top: 5px;
  font-size: 14px;
  color: var(--privy-color-foreground-3);
  text-align: left;
  word-wrap: break-word;
  ${l=>l.$clickable&&`cursor: pointer;
  transition: background-color 0.3s;
  padding-right: 45px;

  &:hover {
    background-color: var(--privy-color-foreground-4);
  }`}
`,gr=h(sr)`
  position: absolute;
  top: 13px;
  right: 13px;
  width: 24px;
  height: 24px;
`,yr=h(Ge)`
  position: absolute;
  top: 13px;
  right: 13px;
  width: 24px;
  height: 24px;
`,kr=({clicked:l})=>e.jsx(l?yr:gr,{});export{Vr as G,Hr as Q,zr as t};
