import{dy as r}from"./PrivyLoginIsland-CDPVUWBM.js";import{n as e}from"./LoadingSkeleton-CeUcJdAQ-CDhyoiGZ.js";const a=r.span`
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  width: 100%;
`,i=r.span`
  display: flex;
  width: 100%;
  justify-content: space-between;
  gap: 0.5rem;
`,o=r.span`
  color: var(--privy-color-foreground-3);
  font-size: 0.875rem;
  font-weight: 400;
  line-height: 1.375rem; /* 157.143% */
`,l=r(o)`
  color: var(--privy-color-accent);
`,s=r.span`
  color: var(--privy-color-foreground);
  font-size: 0.875rem;
  font-weight: 500;
  line-height: 1.375rem; /* 157.143% */
  word-break: break-all;
  text-align: right;

  ${e}
`;export{l as a,o as e,s as n,i as s,a as t};
