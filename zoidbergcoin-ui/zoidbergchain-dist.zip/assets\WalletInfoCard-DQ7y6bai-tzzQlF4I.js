import{d4 as e,dy as r}from"./PrivyLoginIsland-CDPVUWBM.js";import{r as l}from"./index-6mJiZeaw.js";import{$ as p}from"./ModalHeader-DwaDpr9Z-DcVyG2SU.js";import{e as f}from"./ErrorMessage-D8VaAP5m-Yy7PPpsf.js";import{r as x}from"./LabelXs-oqZNqbm_-CyO8h7Kr.js";import{d as h}from"./Address-BPv73sF9-ayAxkKXK.js";import{d as g}from"./shared-FM0rljBt-Dl1dglJ0.js";import{C as u}from"./check-udIDPn4r.js";import{C as j}from"./copy-CUTCh4z2.js";let y=r(g)`
  && {
    padding: 0.75rem;
    height: 56px;
  }
`,C=r.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`,v=r.div`
  display: flex;
  flex-direction: column;
  gap: 0;
`,w=r.div`
  font-size: 12px;
  line-height: 1rem;
  color: var(--privy-color-foreground-3);
`,b=r(x)`
  text-align: left;
  margin-bottom: 0.5rem;
`,z=r(f)`
  margin-top: 0.25rem;
`,E=r(p)`
  && {
    gap: 0.375rem;
    font-size: 14px;
  }
`;const R=({errMsg:t,balance:s,address:n,className:m,title:a,showCopyButton:c=!1})=>{let[i,d]=l.useState(!1);return l.useEffect(()=>{if(i){let o=setTimeout(()=>d(!1),3e3);return()=>clearTimeout(o)}},[i]),e.jsxs("div",{children:[a&&e.jsx(b,{children:a}),e.jsx(y,{className:m,$state:t?"error":void 0,children:e.jsxs(C,{children:[e.jsxs(v,{children:[e.jsx(h,{address:n,showCopyIcon:!1}),s!==void 0&&e.jsx(w,{children:s})]}),c&&e.jsx(E,{onClick:function(o){o.stopPropagation(),navigator.clipboard.writeText(n).then(()=>d(!0)).catch(console.error)},size:"sm",children:e.jsxs(e.Fragment,i?{children:["Copied",e.jsx(u,{size:14})]}:{children:["Copy",e.jsx(j,{size:14})]})})]})}),t&&e.jsx(z,{children:t})]})};export{R as j};
