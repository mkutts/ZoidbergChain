import{d4 as n,dl as j,dh as $,dy as o}from"./PrivyLoginIsland-CDPVUWBM.js";import{i as g,m as c,o as a,c as h}from"./ethers-BuAqeJZn-Wens4q25.js";import{C as k}from"./getFormattedUsdFromLamports-B6EqSEho-UZwDVLSj.js";import{t as y}from"./transaction-CnfuREWo-CCkfWrIi.js";const O=({weiQuantities:e,tokenPrice:i,tokenSymbol:s})=>{let r=c(e),t=i?a(r,i):void 0,l=h(r,s);return n.jsx(d,{children:t||l})},P=({weiQuantities:e,tokenPrice:i,tokenSymbol:s})=>{let r=c(e),t=i?a(r,i):void 0,l=h(r,s);return n.jsx(d,{children:t?n.jsxs(n.Fragment,{children:[n.jsx(S,{children:"USD"}),t==="<$0.01"?n.jsxs(x,{children:[n.jsx(p,{children:"<"}),"$0.01"]}):t]}):l})},D=({quantities:e,tokenPrice:i,tokenSymbol:s="SOL",tokenDecimals:r=9})=>{let t=e.reduce((u,f)=>u+f,0n),l=i&&s==="SOL"&&r===9?k(t,i):void 0,m=s==="SOL"&&r===9?y(t):`${j(t,r)} ${s}`;return n.jsx(d,{children:l?n.jsx(n.Fragment,{children:l==="<$0.01"?n.jsxs(x,{children:[n.jsx(p,{children:"<"}),"$0.01"]}):l}):m})};let d=o.span`
  font-size: 14px;
  line-height: 140%;
  display: flex;
  gap: 4px;
  align-items: center;
`,S=o.span`
  font-size: 12px;
  line-height: 12px;
  color: var(--privy-color-foreground-3);
`,p=o.span`
  font-size: 10px;
`,x=o.span`
  display: flex;
  align-items: center;
`;function w(e,i){return`https://explorer.solana.com/account/${e}?chain=${i}`}const F=e=>n.jsx(b,{href:e.chainType==="ethereum"?g(e.chainId,e.walletAddress):w(e.walletAddress,e.chainId),target:"_blank",children:$(e.walletAddress)});let b=o.a`
  &:hover {
    text-decoration: underline;
  }
`;export{F as S,D as f,P as h,O as p};
