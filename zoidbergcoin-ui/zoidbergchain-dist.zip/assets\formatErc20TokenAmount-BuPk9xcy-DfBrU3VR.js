let t=2n**256n-1n;const e=({amount:m,decimals:n})=>m===t?"Maximum":Intl.NumberFormat(void 0,{maximumFractionDigits:n}).format(Number(m)/10**n);export{e as t};
