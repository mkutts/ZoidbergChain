import{t as n}from"./getFormattedUsdFromLamports-B6EqSEho-UZwDVLSj.js";function f(t){let[e]=Object.entries(n[t]).find(([o,r])=>r.symbol==="USDC")??[];return e}export{f as r};
