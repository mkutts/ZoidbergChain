import{dv as t}from"./PrivyLoginIsland-CDPVUWBM.js";function p(r,e="wei"){return t(r,e)}export{p};
