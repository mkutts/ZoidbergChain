import{e1 as o,e2 as r}from"./PrivyLoginIsland-CDPVUWBM.js";const n=(e,a)=>o(e,a.ethereum.createOnLogin)||r(e,a.solana.createOnLogin);export{n as a};
